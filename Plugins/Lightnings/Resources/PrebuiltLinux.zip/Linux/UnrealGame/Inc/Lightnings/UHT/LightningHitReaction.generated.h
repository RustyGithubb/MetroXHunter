// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

// IWYU pragma: private, include "Parameters/LightningHitReaction.h"
#include "Templates/IsUEnumClass.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ReflectedTypeAccessors.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS
#ifdef LIGHTNINGS_LightningHitReaction_generated_h
#error "LightningHitReaction.generated.h already included, missing '#pragma once' in LightningHitReaction.h"
#endif
#define LIGHTNINGS_LightningHitReaction_generated_h

#undef CURRENT_FILE_ID
#define CURRENT_FILE_ID FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningHitReaction_h


#define FOREACH_ENUM_EHITREACTION(op) \
	op(EHitReaction::HR_Ignore) \
	op(EHitReaction::HR_Discharge) \
	op(EHitReaction::HR_FadeOut) 

enum class EHitReaction : uint8;
template<> struct TIsUEnumClass<EHitReaction> { enum { Value = true }; };
template<> LIGHTNINGS_API UEnum* StaticEnum<EHitReaction>();

PRAGMA_ENABLE_DEPRECATION_WARNINGS
