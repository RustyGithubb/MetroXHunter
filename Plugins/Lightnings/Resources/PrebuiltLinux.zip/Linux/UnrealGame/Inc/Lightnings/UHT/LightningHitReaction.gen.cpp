// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Parameters/LightningHitReaction.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeLightningHitReaction() {}

// Begin Cross Module References
LIGHTNINGS_API UEnum* Z_Construct_UEnum_Lightnings_EHitReaction();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin Enum EHitReaction
static FEnumRegistrationInfo Z_Registration_Info_UEnum_EHitReaction;
static UEnum* EHitReaction_StaticEnum()
{
	if (!Z_Registration_Info_UEnum_EHitReaction.OuterSingleton)
	{
		Z_Registration_Info_UEnum_EHitReaction.OuterSingleton = GetStaticEnum(Z_Construct_UEnum_Lightnings_EHitReaction, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("EHitReaction"));
	}
	return Z_Registration_Info_UEnum_EHitReaction.OuterSingleton;
}
template<> LIGHTNINGS_API UEnum* StaticEnum<EHitReaction>()
{
	return EHitReaction_StaticEnum();
}
struct Z_Construct_UEnum_Lightnings_EHitReaction_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Enum_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* Describes how lightning should react on a hit event\n*/" },
		{ "HR_Discharge.Comment", "// Stop growth, induce discharge (flashing)\n" },
		{ "HR_Discharge.DisplayName", "Discharge" },
		{ "HR_Discharge.Name", "EHitReaction::HR_Discharge" },
		{ "HR_Discharge.ToolTip", "Stop growth, induce discharge (flashing)" },
		{ "HR_FadeOut.Comment", "// Stop growth, start fading out\n" },
		{ "HR_FadeOut.DisplayName", "FadeOut" },
		{ "HR_FadeOut.Name", "EHitReaction::HR_FadeOut" },
		{ "HR_FadeOut.ToolTip", "Stop growth, start fading out" },
		{ "HR_Ignore.Comment", "// No reaction, continue growth\n" },
		{ "HR_Ignore.DisplayName", "Ignore" },
		{ "HR_Ignore.Name", "EHitReaction::HR_Ignore" },
		{ "HR_Ignore.ToolTip", "No reaction, continue growth" },
		{ "ModuleRelativePath", "Public/Parameters/LightningHitReaction.h" },
		{ "ToolTip", "Describes how lightning should react on a hit event" },
	};
#endif // WITH_METADATA
	static constexpr UECodeGen_Private::FEnumeratorParam Enumerators[] = {
		{ "EHitReaction::HR_Ignore", (int64)EHitReaction::HR_Ignore },
		{ "EHitReaction::HR_Discharge", (int64)EHitReaction::HR_Discharge },
		{ "EHitReaction::HR_FadeOut", (int64)EHitReaction::HR_FadeOut },
	};
	static const UECodeGen_Private::FEnumParams EnumParams;
};
const UECodeGen_Private::FEnumParams Z_Construct_UEnum_Lightnings_EHitReaction_Statics::EnumParams = {
	(UObject*(*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	"EHitReaction",
	"EHitReaction",
	Z_Construct_UEnum_Lightnings_EHitReaction_Statics::Enumerators,
	RF_Public|RF_Transient|RF_MarkAsNative,
	UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EHitReaction_Statics::Enumerators),
	EEnumFlags::None,
	(uint8)UEnum::ECppForm::EnumClass,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EHitReaction_Statics::Enum_MetaDataParams), Z_Construct_UEnum_Lightnings_EHitReaction_Statics::Enum_MetaDataParams)
};
UEnum* Z_Construct_UEnum_Lightnings_EHitReaction()
{
	if (!Z_Registration_Info_UEnum_EHitReaction.InnerSingleton)
	{
		UECodeGen_Private::ConstructUEnum(Z_Registration_Info_UEnum_EHitReaction.InnerSingleton, Z_Construct_UEnum_Lightnings_EHitReaction_Statics::EnumParams);
	}
	return Z_Registration_Info_UEnum_EHitReaction.InnerSingleton;
}
// End Enum EHitReaction

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningHitReaction_h_Statics
{
	static constexpr FEnumRegisterCompiledInInfo EnumInfo[] = {
		{ EHitReaction_StaticEnum, TEXT("EHitReaction"), &Z_Registration_Info_UEnum_EHitReaction, CONSTRUCT_RELOAD_VERSION_INFO(FEnumReloadVersionInfo, 2298368100U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningHitReaction_h_3044532820(TEXT("/Script/Lightnings"),
	nullptr, 0,
	nullptr, 0,
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningHitReaction_h_Statics::EnumInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningHitReaction_h_Statics::EnumInfo));
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
