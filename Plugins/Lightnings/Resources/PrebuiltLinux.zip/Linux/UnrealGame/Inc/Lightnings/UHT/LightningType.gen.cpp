// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Parameters/LightningType.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeLightningType() {}

// Begin Cross Module References
LIGHTNINGS_API UEnum* Z_Construct_UEnum_Lightnings_ELightningType();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin Enum ELightningType
static FEnumRegistrationInfo Z_Registration_Info_UEnum_ELightningType;
static UEnum* ELightningType_StaticEnum()
{
	if (!Z_Registration_Info_UEnum_ELightningType.OuterSingleton)
	{
		Z_Registration_Info_UEnum_ELightningType.OuterSingleton = GetStaticEnum(Z_Construct_UEnum_Lightnings_ELightningType, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("ELightningType"));
	}
	return Z_Registration_Info_UEnum_ELightningType.OuterSingleton;
}
template<> LIGHTNINGS_API UEnum* StaticEnum<ELightningType>()
{
	return ELightningType_StaticEnum();
}
struct Z_Construct_UEnum_Lightnings_ELightningType_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Enum_MetaDataParams[] = {
		{ "LT_Branch.Name", "ELightningType::LT_Branch" },
		{ "LT_Root.Name", "ELightningType::LT_Root" },
		{ "ModuleRelativePath", "Public/Parameters/LightningType.h" },
	};
#endif // WITH_METADATA
	static constexpr UECodeGen_Private::FEnumeratorParam Enumerators[] = {
		{ "ELightningType::LT_Root", (int64)ELightningType::LT_Root },
		{ "ELightningType::LT_Branch", (int64)ELightningType::LT_Branch },
	};
	static const UECodeGen_Private::FEnumParams EnumParams;
};
const UECodeGen_Private::FEnumParams Z_Construct_UEnum_Lightnings_ELightningType_Statics::EnumParams = {
	(UObject*(*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	"ELightningType",
	"ELightningType",
	Z_Construct_UEnum_Lightnings_ELightningType_Statics::Enumerators,
	RF_Public|RF_Transient|RF_MarkAsNative,
	UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_ELightningType_Statics::Enumerators),
	EEnumFlags::None,
	(uint8)UEnum::ECppForm::EnumClass,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_ELightningType_Statics::Enum_MetaDataParams), Z_Construct_UEnum_Lightnings_ELightningType_Statics::Enum_MetaDataParams)
};
UEnum* Z_Construct_UEnum_Lightnings_ELightningType()
{
	if (!Z_Registration_Info_UEnum_ELightningType.InnerSingleton)
	{
		UECodeGen_Private::ConstructUEnum(Z_Registration_Info_UEnum_ELightningType.InnerSingleton, Z_Construct_UEnum_Lightnings_ELightningType_Statics::EnumParams);
	}
	return Z_Registration_Info_UEnum_ELightningType.InnerSingleton;
}
// End Enum ELightningType

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningType_h_Statics
{
	static constexpr FEnumRegisterCompiledInInfo EnumInfo[] = {
		{ ELightningType_StaticEnum, TEXT("ELightningType"), &Z_Registration_Info_UEnum_ELightningType, CONSTRUCT_RELOAD_VERSION_INFO(FEnumReloadVersionInfo, 2719266830U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningType_h_3477203583(TEXT("/Script/Lightnings"),
	nullptr, 0,
	nullptr, 0,
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningType_h_Statics::EnumInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningType_h_Statics::EnumInfo));
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
