// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Framework/LightningEffect.h"
#include "Lightnings/Public/Framework/LightningPattern.h"
#include "Lightnings/Public/Parameters/LightningParams.h"
#include "Runtime/Engine/Classes/Engine/HitResult.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeLightningEffect() {}

// Begin Cross Module References
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FVector();
ENGINE_API UClass* Z_Construct_UClass_AActor();
ENGINE_API UClass* Z_Construct_UClass_UBillboardComponent_NoRegister();
ENGINE_API UEnum* Z_Construct_UEnum_Engine_ECollisionResponse();
ENGINE_API UScriptStruct* Z_Construct_UScriptStruct_FHitResult();
LIGHTNINGS_API UClass* Z_Construct_UClass_ALightningEffect();
LIGHTNINGS_API UClass* Z_Construct_UClass_ALightningEffect_NoRegister();
LIGHTNINGS_API UClass* Z_Construct_UClass_ALightningEmitter_NoRegister();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningIntensityParams();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningParams();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningPattern();
NIAGARA_API UClass* Z_Construct_UClass_UNiagaraComponent_NoRegister();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin Delegate FLightningSpawnedSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventLightningSpawnedSignature_Parms
	{
		ALightningEffect* Lightning;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Lightning;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::NewProp_Lightning = { "Lightning", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningSpawnedSignature_Parms, Lightning), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::NewProp_Lightning,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "LightningSpawnedSignature__DelegateSignature", "LightningEffect", "EventOnLightningSpawned", Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningSpawnedSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningSpawnedSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FLightningSpawnedSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningSpawnedSignature, ALightningEffect* Lightning)
{
	struct _Script_Lightnings_eventLightningSpawnedSignature_Parms
	{
		ALightningEffect* Lightning;
	};
	_Script_Lightnings_eventLightningSpawnedSignature_Parms Parms;
	Parms.Lightning=Lightning;
	LightningSpawnedSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FLightningSpawnedSignature

// Begin Delegate FLightningSparkMoveSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventLightningSparkMoveSignature_Parms
	{
		ALightningEffect* Lightning;
		FVector Start;
		FVector End;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Lightning;
	static const UECodeGen_Private::FStructPropertyParams NewProp_Start;
	static const UECodeGen_Private::FStructPropertyParams NewProp_End;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::NewProp_Lightning = { "Lightning", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningSparkMoveSignature_Parms, Lightning), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::NewProp_Start = { "Start", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningSparkMoveSignature_Parms, Start), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::NewProp_End = { "End", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningSparkMoveSignature_Parms, End), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::NewProp_Lightning,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::NewProp_Start,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::NewProp_End,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "LightningSparkMoveSignature__DelegateSignature", "LightningEffect", "EventOnLightningSparkMove", Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningSparkMoveSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningSparkMoveSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FLightningSparkMoveSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningSparkMoveSignature, ALightningEffect* Lightning, FVector Start, FVector End)
{
	struct _Script_Lightnings_eventLightningSparkMoveSignature_Parms
	{
		ALightningEffect* Lightning;
		FVector Start;
		FVector End;
	};
	_Script_Lightnings_eventLightningSparkMoveSignature_Parms Parms;
	Parms.Lightning=Lightning;
	Parms.Start=Start;
	Parms.End=End;
	LightningSparkMoveSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FLightningSparkMoveSignature

// Begin Delegate FLightningSparkEndMoveSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventLightningSparkEndMoveSignature_Parms
	{
		ALightningEffect* Lightning;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Lightning;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::NewProp_Lightning = { "Lightning", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningSparkEndMoveSignature_Parms, Lightning), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::NewProp_Lightning,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "LightningSparkEndMoveSignature__DelegateSignature", "LightningEffect", "EventOnLightningSparkEndMove", Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningSparkEndMoveSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningSparkEndMoveSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FLightningSparkEndMoveSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningSparkEndMoveSignature, ALightningEffect* Lightning)
{
	struct _Script_Lightnings_eventLightningSparkEndMoveSignature_Parms
	{
		ALightningEffect* Lightning;
	};
	_Script_Lightnings_eventLightningSparkEndMoveSignature_Parms Parms;
	Parms.Lightning=Lightning;
	LightningSparkEndMoveSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FLightningSparkEndMoveSignature

// Begin Delegate FLightningBranchedSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventLightningBranchedSignature_Parms
	{
		ALightningEffect* Lightning;
		ALightningEffect* Branch;
		int32 BranchOrder;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Lightning;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Branch;
	static const UECodeGen_Private::FIntPropertyParams NewProp_BranchOrder;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::NewProp_Lightning = { "Lightning", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningBranchedSignature_Parms, Lightning), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::NewProp_Branch = { "Branch", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningBranchedSignature_Parms, Branch), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FIntPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::NewProp_BranchOrder = { "BranchOrder", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningBranchedSignature_Parms, BranchOrder), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::NewProp_Lightning,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::NewProp_Branch,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::NewProp_BranchOrder,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "LightningBranchedSignature__DelegateSignature", "LightningEffect", "EventOnLightningBranched", Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningBranchedSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningBranchedSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FLightningBranchedSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningBranchedSignature, ALightningEffect* Lightning, ALightningEffect* Branch, int32 BranchOrder)
{
	struct _Script_Lightnings_eventLightningBranchedSignature_Parms
	{
		ALightningEffect* Lightning;
		ALightningEffect* Branch;
		int32 BranchOrder;
	};
	_Script_Lightnings_eventLightningBranchedSignature_Parms Parms;
	Parms.Lightning=Lightning;
	Parms.Branch=Branch;
	Parms.BranchOrder=BranchOrder;
	LightningBranchedSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FLightningBranchedSignature

// Begin Delegate FIntensityChangedSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventIntensityChangedSignature_Parms
	{
		ALightningEffect* Lightning;
		float Intensity;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Lightning;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Intensity;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::NewProp_Lightning = { "Lightning", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventIntensityChangedSignature_Parms, Lightning), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::NewProp_Intensity = { "Intensity", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventIntensityChangedSignature_Parms, Intensity), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::NewProp_Lightning,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::NewProp_Intensity,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "IntensityChangedSignature__DelegateSignature", "LightningEffect", "EventOnIntensityChanged", Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::_Script_Lightnings_eventIntensityChangedSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::_Script_Lightnings_eventIntensityChangedSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FIntensityChangedSignature_DelegateWrapper(const FMulticastScriptDelegate& IntensityChangedSignature, ALightningEffect* Lightning, float Intensity)
{
	struct _Script_Lightnings_eventIntensityChangedSignature_Parms
	{
		ALightningEffect* Lightning;
		float Intensity;
	};
	_Script_Lightnings_eventIntensityChangedSignature_Parms Parms;
	Parms.Lightning=Lightning;
	Parms.Intensity=Intensity;
	IntensityChangedSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FIntensityChangedSignature

// Begin Delegate FLightningOverlapSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventLightningOverlapSignature_Parms
	{
		ALightningEffect* Lightning;
		TArray<FHitResult> Overlaps;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Overlaps_MetaData[] = {
		{ "NativeConst", "" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Lightning;
	static const UECodeGen_Private::FStructPropertyParams NewProp_Overlaps_Inner;
	static const UECodeGen_Private::FArrayPropertyParams NewProp_Overlaps;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::NewProp_Lightning = { "Lightning", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningOverlapSignature_Parms, Lightning), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::NewProp_Overlaps_Inner = { "Overlaps", nullptr, (EPropertyFlags)0x0000008000000000, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, Z_Construct_UScriptStruct_FHitResult, METADATA_PARAMS(0, nullptr) }; // 4100991306
const UECodeGen_Private::FArrayPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::NewProp_Overlaps = { "Overlaps", nullptr, (EPropertyFlags)0x0010008008000182, UECodeGen_Private::EPropertyGenFlags::Array, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningOverlapSignature_Parms, Overlaps), EArrayPropertyFlags::None, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Overlaps_MetaData), NewProp_Overlaps_MetaData) }; // 4100991306
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::NewProp_Lightning,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::NewProp_Overlaps_Inner,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::NewProp_Overlaps,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "LightningOverlapSignature__DelegateSignature", "LightningEffect", "EventOnLightningOverlap", Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningOverlapSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningOverlapSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FLightningOverlapSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningOverlapSignature, ALightningEffect* Lightning, TArray<FHitResult> const& Overlaps)
{
	struct _Script_Lightnings_eventLightningOverlapSignature_Parms
	{
		ALightningEffect* Lightning;
		TArray<FHitResult> Overlaps;
	};
	_Script_Lightnings_eventLightningOverlapSignature_Parms Parms;
	Parms.Lightning=Lightning;
	Parms.Overlaps=Overlaps;
	LightningOverlapSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FLightningOverlapSignature

// Begin Delegate FLightningHitSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventLightningHitSignature_Parms
	{
		ALightningEffect* Lightning;
		FHitResult Hit;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Lightning;
	static const UECodeGen_Private::FStructPropertyParams NewProp_Hit;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::NewProp_Lightning = { "Lightning", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningHitSignature_Parms, Lightning), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::NewProp_Hit = { "Hit", nullptr, (EPropertyFlags)0x0010008000000080, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventLightningHitSignature_Parms, Hit), Z_Construct_UScriptStruct_FHitResult, METADATA_PARAMS(0, nullptr) }; // 4100991306
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::NewProp_Lightning,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::NewProp_Hit,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "LightningHitSignature__DelegateSignature", "LightningEffect", "EventOnLightningHit", Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningHitSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::_Script_Lightnings_eventLightningHitSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FLightningHitSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningHitSignature, ALightningEffect* Lightning, FHitResult Hit)
{
	struct _Script_Lightnings_eventLightningHitSignature_Parms
	{
		ALightningEffect* Lightning;
		FHitResult Hit;
	};
	_Script_Lightnings_eventLightningHitSignature_Parms Parms;
	Parms.Lightning=Lightning;
	Parms.Hit=Hit;
	LightningHitSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FLightningHitSignature

// Begin ScriptStruct FLightningIntensityParams
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_LightningIntensityParams;
class UScriptStruct* FLightningIntensityParams::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_LightningIntensityParams.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_LightningIntensityParams.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FLightningIntensityParams, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("LightningIntensityParams"));
	}
	return Z_Registration_Info_UScriptStruct_LightningIntensityParams.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FLightningIntensityParams>()
{
	return FLightningIntensityParams::StaticStruct();
}
struct Z_Construct_UScriptStruct_FLightningIntensityParams_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkIntensity_MetaData[] = {
		{ "Category", "LightningIntensity" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_TrailIntensity_MetaData[] = {
		{ "Category", "LightningIntensity" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BoltIntensity_MetaData[] = {
		{ "Category", "LightningIntensity" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFloatPropertyParams NewProp_SparkIntensity;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_TrailIntensity;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_BoltIntensity;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FLightningIntensityParams>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::NewProp_SparkIntensity = { "SparkIntensity", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningIntensityParams, SparkIntensity), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkIntensity_MetaData), NewProp_SparkIntensity_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::NewProp_TrailIntensity = { "TrailIntensity", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningIntensityParams, TrailIntensity), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_TrailIntensity_MetaData), NewProp_TrailIntensity_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::NewProp_BoltIntensity = { "BoltIntensity", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningIntensityParams, BoltIntensity), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BoltIntensity_MetaData), NewProp_BoltIntensity_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::NewProp_SparkIntensity,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::NewProp_TrailIntensity,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::NewProp_BoltIntensity,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"LightningIntensityParams",
	Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::PropPointers),
	sizeof(FLightningIntensityParams),
	alignof(FLightningIntensityParams),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FLightningIntensityParams()
{
	if (!Z_Registration_Info_UScriptStruct_LightningIntensityParams.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_LightningIntensityParams.InnerSingleton, Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_LightningIntensityParams.InnerSingleton;
}
// End ScriptStruct FLightningIntensityParams

// Begin Class ALightningEffect Function Deactivate
struct Z_Construct_UFunction_ALightningEffect_Deactivate_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "/**\n\x09* Flashing timeline function (Finish)\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Flashing timeline function (Finish)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_Deactivate_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "Deactivate", nullptr, nullptr, nullptr, 0, 0, RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_Deactivate_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_Deactivate_Statics::Function_MetaDataParams) };
UFunction* Z_Construct_UFunction_ALightningEffect_Deactivate()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_Deactivate_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execDeactivate)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->Deactivate();
	P_NATIVE_END;
}
// End Class ALightningEffect Function Deactivate

// Begin Class ALightningEffect Function Discharge
struct Z_Construct_UFunction_ALightningEffect_Discharge_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "Lightning" },
		{ "Comment", "// Stop lightning growth and run discharge animation (works only if root)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Stop lightning growth and run discharge animation (works only if root)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_Discharge_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "Discharge", nullptr, nullptr, nullptr, 0, 0, RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x04020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_Discharge_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_Discharge_Statics::Function_MetaDataParams) };
UFunction* Z_Construct_UFunction_ALightningEffect_Discharge()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_Discharge_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execDischarge)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->Discharge();
	P_NATIVE_END;
}
// End Class ALightningEffect Function Discharge

// Begin Class ALightningEffect Function DoCollisionCheck
struct Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics
{
	struct LightningEffect_eventDoCollisionCheck_Parms
	{
		FVector Start;
		FVector End;
		TEnumAsByte<ECollisionResponse> Response;
		int32 MaxResults;
		TArray<FHitResult> OutHits;
		bool ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "Lightning" },
		{ "Comment", "/**\n\x09* Check Start-End line to any collisions\n\x09*\n\x09* @param Start - The first point for the line\n\x09* @param End - The second point for the line\n\x09* @param Response - The required collision response\n\x09* @param MaxResults - A limit of collisions to check ((MaxResults < 0) == infinite)\n\x09* @param OutHits - A result array reference\n\x09* \n\x09* @return true if there were any collisions\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Check Start-End line to any collisions\n\n@param Start - The first point for the line\n@param End - The second point for the line\n@param Response - The required collision response\n@param MaxResults - A limit of collisions to check ((MaxResults < 0) == infinite)\n@param OutHits - A result array reference\n\n@return true if there were any collisions" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Start_MetaData[] = {
		{ "NativeConst", "" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_End_MetaData[] = {
		{ "NativeConst", "" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Start;
	static const UECodeGen_Private::FStructPropertyParams NewProp_End;
	static const UECodeGen_Private::FBytePropertyParams NewProp_Response;
	static const UECodeGen_Private::FIntPropertyParams NewProp_MaxResults;
	static const UECodeGen_Private::FStructPropertyParams NewProp_OutHits_Inner;
	static const UECodeGen_Private::FArrayPropertyParams NewProp_OutHits;
	static void NewProp_ReturnValue_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_Start = { "Start", nullptr, (EPropertyFlags)0x0010000008000182, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventDoCollisionCheck_Parms, Start), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Start_MetaData), NewProp_Start_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_End = { "End", nullptr, (EPropertyFlags)0x0010000008000182, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventDoCollisionCheck_Parms, End), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_End_MetaData), NewProp_End_MetaData) };
const UECodeGen_Private::FBytePropertyParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_Response = { "Response", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Byte, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventDoCollisionCheck_Parms, Response), Z_Construct_UEnum_Engine_ECollisionResponse, METADATA_PARAMS(0, nullptr) }; // 1009580041
const UECodeGen_Private::FIntPropertyParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_MaxResults = { "MaxResults", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventDoCollisionCheck_Parms, MaxResults), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_OutHits_Inner = { "OutHits", nullptr, (EPropertyFlags)0x0000008000000000, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, Z_Construct_UScriptStruct_FHitResult, METADATA_PARAMS(0, nullptr) }; // 4100991306
const UECodeGen_Private::FArrayPropertyParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_OutHits = { "OutHits", nullptr, (EPropertyFlags)0x0010008000000180, UECodeGen_Private::EPropertyGenFlags::Array, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventDoCollisionCheck_Parms, OutHits), EArrayPropertyFlags::None, METADATA_PARAMS(0, nullptr) }; // 4100991306
void Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_ReturnValue_SetBit(void* Obj)
{
	((LightningEffect_eventDoCollisionCheck_Parms*)Obj)->ReturnValue = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(LightningEffect_eventDoCollisionCheck_Parms), &Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_ReturnValue_SetBit, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_Start,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_End,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_Response,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_MaxResults,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_OutHits_Inner,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_OutHits,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "DoCollisionCheck", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::LightningEffect_eventDoCollisionCheck_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x04C20401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::LightningEffect_eventDoCollisionCheck_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_DoCollisionCheck()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_DoCollisionCheck_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execDoCollisionCheck)
{
	P_GET_STRUCT_REF(FVector,Z_Param_Out_Start);
	P_GET_STRUCT_REF(FVector,Z_Param_Out_End);
	P_GET_PROPERTY(FByteProperty,Z_Param_Response);
	P_GET_PROPERTY(FIntProperty,Z_Param_MaxResults);
	P_GET_TARRAY_REF(FHitResult,Z_Param_Out_OutHits);
	P_FINISH;
	P_NATIVE_BEGIN;
	*(bool*)Z_Param__Result=P_THIS->DoCollisionCheck(Z_Param_Out_Start,Z_Param_Out_End,ECollisionResponse(Z_Param_Response),Z_Param_MaxResults,Z_Param_Out_OutHits);
	P_NATIVE_END;
}
// End Class ALightningEffect Function DoCollisionCheck

// Begin Class ALightningEffect Function FadeOut
struct Z_Construct_UFunction_ALightningEffect_FadeOut_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "Lightning" },
		{ "Comment", "// Stop lightning growth and fade it out\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Stop lightning growth and fade it out" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_FadeOut_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "FadeOut", nullptr, nullptr, nullptr, 0, 0, RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x04020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_FadeOut_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_FadeOut_Statics::Function_MetaDataParams) };
UFunction* Z_Construct_UFunction_ALightningEffect_FadeOut()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_FadeOut_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execFadeOut)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->FadeOut();
	P_NATIVE_END;
}
// End Class ALightningEffect Function FadeOut

// Begin Class ALightningEffect Function GetOrder
struct Z_Construct_UFunction_ALightningEffect_GetOrder_Statics
{
	struct LightningEffect_eventGetOrder_Parms
	{
		int32 ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "Lightning" },
		{ "Comment", "// Get lightning's order (0 if root, >0 for branches)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Get lightning's order (0 if root, >0 for branches)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FIntPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FIntPropertyParams Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventGetOrder_Parms, ReturnValue), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "GetOrder", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::LightningEffect_eventGetOrder_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x54020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::LightningEffect_eventGetOrder_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_GetOrder()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_GetOrder_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execGetOrder)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	*(int32*)Z_Param__Result=P_THIS->GetOrder();
	P_NATIVE_END;
}
// End Class ALightningEffect Function GetOrder

// Begin Class ALightningEffect Function GetPattern
struct Z_Construct_UFunction_ALightningEffect_GetPattern_Statics
{
	struct LightningEffect_eventGetPattern_Parms
	{
		FLightningPattern ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "Lightning" },
		{ "Comment", "/**\n\x09* =============================================================\n\x09* User blueprint callable functions\n\x09*/// Returns an actual pattern object (a copy)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "User blueprint callable functions\n       // Returns an actual pattern object (a copy)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventGetPattern_Parms, ReturnValue), Z_Construct_UScriptStruct_FLightningPattern, METADATA_PARAMS(0, nullptr) }; // 2025616064
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "GetPattern", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::LightningEffect_eventGetPattern_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x54020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::LightningEffect_eventGetPattern_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_GetPattern()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_GetPattern_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execGetPattern)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	*(FLightningPattern*)Z_Param__Result=P_THIS->GetPattern();
	P_NATIVE_END;
}
// End Class ALightningEffect Function GetPattern

// Begin Class ALightningEffect Function IsRoot
struct Z_Construct_UFunction_ALightningEffect_IsRoot_Statics
{
	struct LightningEffect_eventIsRoot_Parms
	{
		bool ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "Lightning" },
		{ "Comment", "// Check whether this lightning is a root\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Check whether this lightning is a root" },
	};
#endif // WITH_METADATA
	static void NewProp_ReturnValue_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
void Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::NewProp_ReturnValue_SetBit(void* Obj)
{
	((LightningEffect_eventIsRoot_Parms*)Obj)->ReturnValue = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(LightningEffect_eventIsRoot_Parms), &Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::NewProp_ReturnValue_SetBit, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "IsRoot", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::LightningEffect_eventIsRoot_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x54020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::LightningEffect_eventIsRoot_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_IsRoot()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_IsRoot_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execIsRoot)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	*(bool*)Z_Param__Result=P_THIS->IsRoot();
	P_NATIVE_END;
}
// End Class ALightningEffect Function IsRoot

// Begin Class ALightningEffect Function OnBoltFlashing
struct Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics
{
	struct LightningEffect_eventOnBoltFlashing_Parms
	{
		float Alpha;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "/**\n\x09* Flashing timeline function (Update)\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Flashing timeline function (Update)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Alpha;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::NewProp_Alpha = { "Alpha", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnBoltFlashing_Parms, Alpha), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::NewProp_Alpha,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnBoltFlashing", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::LightningEffect_eventOnBoltFlashing_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::LightningEffect_eventOnBoltFlashing_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_OnBoltFlashing()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnBoltFlashing_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnBoltFlashing)
{
	P_GET_PROPERTY(FFloatProperty,Z_Param_Alpha);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnBoltFlashing(Z_Param_Alpha);
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnBoltFlashing

// Begin Class ALightningEffect Function OnIntensityChanged
struct LightningEffect_eventOnIntensityChanged_Parms
{
	float Intensity;
};
static FName NAME_ALightningEffect_OnIntensityChanged = FName(TEXT("OnIntensityChanged"));
void ALightningEffect::OnIntensityChanged(float Intensity)
{
	LightningEffect_eventOnIntensityChanged_Parms Parms;
	Parms.Intensity=Intensity;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEffect_OnIntensityChanged),&Parms);
}
struct Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "// Called when intensity of lightning is changed (when the lightning is flashing for example)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when intensity of lightning is changed (when the lightning is flashing for example)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Intensity;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::NewProp_Intensity = { "Intensity", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnIntensityChanged_Parms, Intensity), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::NewProp_Intensity,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnIntensityChanged", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::PropPointers), sizeof(LightningEffect_eventOnIntensityChanged_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08020C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEffect_eventOnIntensityChanged_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_OnIntensityChanged()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnIntensityChanged_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnIntensityChanged)
{
	P_GET_PROPERTY(FFloatProperty,Z_Param_Intensity);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnIntensityChanged_Implementation(Z_Param_Intensity);
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnIntensityChanged

// Begin Class ALightningEffect Function OnLightningBranched
struct LightningEffect_eventOnLightningBranched_Parms
{
	ALightningEffect* Branch;
	int32 BranchOrder;
};
static FName NAME_ALightningEffect_OnLightningBranched = FName(TEXT("OnLightningBranched"));
void ALightningEffect::OnLightningBranched(ALightningEffect* Branch, int32 BranchOrder)
{
	LightningEffect_eventOnLightningBranched_Parms Parms;
	Parms.Branch=Branch;
	Parms.BranchOrder=BranchOrder;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEffect_OnLightningBranched),&Parms);
}
struct Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "/**\n\x09* Called when lightning is branched\n\x09* @param Branch - new spawned lightning effect actor of the branch;\n\x09* @param Order - branch order\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when lightning is branched\n@param Branch - new spawned lightning effect actor of the branch;\n@param Order - branch order" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Branch;
	static const UECodeGen_Private::FIntPropertyParams NewProp_BranchOrder;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::NewProp_Branch = { "Branch", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnLightningBranched_Parms, Branch), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FIntPropertyParams Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::NewProp_BranchOrder = { "BranchOrder", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnLightningBranched_Parms, BranchOrder), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::NewProp_Branch,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::NewProp_BranchOrder,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnLightningBranched", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::PropPointers), sizeof(LightningEffect_eventOnLightningBranched_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08020C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEffect_eventOnLightningBranched_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_OnLightningBranched()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnLightningBranched_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnLightningBranched)
{
	P_GET_OBJECT(ALightningEffect,Z_Param_Branch);
	P_GET_PROPERTY(FIntProperty,Z_Param_BranchOrder);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnLightningBranched_Implementation(Z_Param_Branch,Z_Param_BranchOrder);
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnLightningBranched

// Begin Class ALightningEffect Function OnLightningHit
struct LightningEffect_eventOnLightningHit_Parms
{
	FHitResult Hit;
};
static FName NAME_ALightningEffect_OnLightningHit = FName(TEXT("OnLightningHit"));
void ALightningEffect::OnLightningHit(FHitResult Hit)
{
	LightningEffect_eventOnLightningHit_Parms Parms;
	Parms.Hit=Hit;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEffect_OnLightningHit),&Parms);
}
struct Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "// Called when a lightning hits an actor in the world\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when a lightning hits an actor in the world" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Hit;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::NewProp_Hit = { "Hit", nullptr, (EPropertyFlags)0x0010008000000080, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnLightningHit_Parms, Hit), Z_Construct_UScriptStruct_FHitResult, METADATA_PARAMS(0, nullptr) }; // 4100991306
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::NewProp_Hit,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnLightningHit", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::PropPointers), sizeof(LightningEffect_eventOnLightningHit_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08020C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEffect_eventOnLightningHit_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_OnLightningHit()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnLightningHit_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnLightningHit)
{
	P_GET_STRUCT(FHitResult,Z_Param_Hit);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnLightningHit_Implementation(Z_Param_Hit);
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnLightningHit

// Begin Class ALightningEffect Function OnLightningOverlap
struct LightningEffect_eventOnLightningOverlap_Parms
{
	TArray<FHitResult> Overlaps;
};
static FName NAME_ALightningEffect_OnLightningOverlap = FName(TEXT("OnLightningOverlap"));
void ALightningEffect::OnLightningOverlap(TArray<FHitResult> const& Overlaps)
{
	LightningEffect_eventOnLightningOverlap_Parms Parms;
	Parms.Overlaps=Overlaps;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEffect_OnLightningOverlap),&Parms);
}
struct Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "// Called when a lightning overlaps an actor (or several) in the world\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when a lightning overlaps an actor (or several) in the world" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Overlaps_MetaData[] = {
		{ "NativeConst", "" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Overlaps_Inner;
	static const UECodeGen_Private::FArrayPropertyParams NewProp_Overlaps;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::NewProp_Overlaps_Inner = { "Overlaps", nullptr, (EPropertyFlags)0x0000008000000000, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, Z_Construct_UScriptStruct_FHitResult, METADATA_PARAMS(0, nullptr) }; // 4100991306
const UECodeGen_Private::FArrayPropertyParams Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::NewProp_Overlaps = { "Overlaps", nullptr, (EPropertyFlags)0x0010008008000182, UECodeGen_Private::EPropertyGenFlags::Array, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnLightningOverlap_Parms, Overlaps), EArrayPropertyFlags::None, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Overlaps_MetaData), NewProp_Overlaps_MetaData) }; // 4100991306
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::NewProp_Overlaps_Inner,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::NewProp_Overlaps,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnLightningOverlap", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::PropPointers), sizeof(LightningEffect_eventOnLightningOverlap_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08420C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEffect_eventOnLightningOverlap_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_OnLightningOverlap()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnLightningOverlap_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnLightningOverlap)
{
	P_GET_TARRAY_REF(FHitResult,Z_Param_Out_Overlaps);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnLightningOverlap_Implementation(Z_Param_Out_Overlaps);
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnLightningOverlap

// Begin Class ALightningEffect Function OnLightningSparkEndMove
static FName NAME_ALightningEffect_OnLightningSparkEndMove = FName(TEXT("OnLightningSparkEndMove"));
void ALightningEffect::OnLightningSparkEndMove()
{
	ProcessEvent(FindFunctionChecked(NAME_ALightningEffect_OnLightningSparkEndMove),NULL);
}
struct Z_Construct_UFunction_ALightningEffect_OnLightningSparkEndMove_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "// Called when lightning spark has reached Target Attachment point (lightning is fully formed)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when lightning spark has reached Target Attachment point (lightning is fully formed)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnLightningSparkEndMove_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnLightningSparkEndMove", nullptr, nullptr, nullptr, 0, 0, RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08020C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningSparkEndMove_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnLightningSparkEndMove_Statics::Function_MetaDataParams) };
UFunction* Z_Construct_UFunction_ALightningEffect_OnLightningSparkEndMove()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnLightningSparkEndMove_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnLightningSparkEndMove)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnLightningSparkEndMove_Implementation();
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnLightningSparkEndMove

// Begin Class ALightningEffect Function OnLightningSparkMove
struct LightningEffect_eventOnLightningSparkMove_Parms
{
	FVector Start;
	FVector End;
};
static FName NAME_ALightningEffect_OnLightningSparkMove = FName(TEXT("OnLightningSparkMove"));
void ALightningEffect::OnLightningSparkMove(FVector Start, FVector End)
{
	LightningEffect_eventOnLightningSparkMove_Parms Parms;
	Parms.Start=Start;
	Parms.End=End;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEffect_OnLightningSparkMove),&Parms);
}
struct Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "// Called when lightning spark has moved between Start and End points\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when lightning spark has moved between Start and End points" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Start;
	static const UECodeGen_Private::FStructPropertyParams NewProp_End;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::NewProp_Start = { "Start", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnLightningSparkMove_Parms, Start), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::NewProp_End = { "End", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEffect_eventOnLightningSparkMove_Parms, End), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::NewProp_Start,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::NewProp_End,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnLightningSparkMove", nullptr, nullptr, Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::PropPointers), sizeof(LightningEffect_eventOnLightningSparkMove_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08820C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEffect_eventOnLightningSparkMove_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnLightningSparkMove)
{
	P_GET_STRUCT(FVector,Z_Param_Start);
	P_GET_STRUCT(FVector,Z_Param_End);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnLightningSparkMove_Implementation(Z_Param_Start,Z_Param_End);
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnLightningSparkMove

// Begin Class ALightningEffect Function OnLightningSpawned
static FName NAME_ALightningEffect_OnLightningSpawned = FName(TEXT("OnLightningSpawned"));
void ALightningEffect::OnLightningSpawned()
{
	ProcessEvent(FindFunctionChecked(NAME_ALightningEffect_OnLightningSpawned),NULL);
}
struct Z_Construct_UFunction_ALightningEffect_OnLightningSpawned_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "/** \n\x09* =============================================================\n\x09* Runtime Blueprint events\n\x09*/// Called when lightning is setup with emitter params (analog for BeginPlay event)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Runtime Blueprint events\n       // Called when lightning is setup with emitter params (analog for BeginPlay event)" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEffect_OnLightningSpawned_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEffect, nullptr, "OnLightningSpawned", nullptr, nullptr, nullptr, 0, 0, RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08020C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEffect_OnLightningSpawned_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEffect_OnLightningSpawned_Statics::Function_MetaDataParams) };
UFunction* Z_Construct_UFunction_ALightningEffect_OnLightningSpawned()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEffect_OnLightningSpawned_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEffect::execOnLightningSpawned)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnLightningSpawned_Implementation();
	P_NATIVE_END;
}
// End Class ALightningEffect Function OnLightningSpawned

// Begin Class ALightningEffect
void ALightningEffect::StaticRegisterNativesALightningEffect()
{
	UClass* Class = ALightningEffect::StaticClass();
	static const FNameNativePtrPair Funcs[] = {
		{ "Deactivate", &ALightningEffect::execDeactivate },
		{ "Discharge", &ALightningEffect::execDischarge },
		{ "DoCollisionCheck", &ALightningEffect::execDoCollisionCheck },
		{ "FadeOut", &ALightningEffect::execFadeOut },
		{ "GetOrder", &ALightningEffect::execGetOrder },
		{ "GetPattern", &ALightningEffect::execGetPattern },
		{ "IsRoot", &ALightningEffect::execIsRoot },
		{ "OnBoltFlashing", &ALightningEffect::execOnBoltFlashing },
		{ "OnIntensityChanged", &ALightningEffect::execOnIntensityChanged },
		{ "OnLightningBranched", &ALightningEffect::execOnLightningBranched },
		{ "OnLightningHit", &ALightningEffect::execOnLightningHit },
		{ "OnLightningOverlap", &ALightningEffect::execOnLightningOverlap },
		{ "OnLightningSparkEndMove", &ALightningEffect::execOnLightningSparkEndMove },
		{ "OnLightningSparkMove", &ALightningEffect::execOnLightningSparkMove },
		{ "OnLightningSpawned", &ALightningEffect::execOnLightningSpawned },
	};
	FNativeFunctionRegistrar::RegisterFunctions(Class, Funcs, UE_ARRAY_COUNT(Funcs));
}
IMPLEMENT_CLASS_NO_AUTO_REGISTRATION(ALightningEffect);
UClass* Z_Construct_UClass_ALightningEffect_NoRegister()
{
	return ALightningEffect::StaticClass();
}
struct Z_Construct_UClass_ALightningEffect_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Class_MetaDataParams[] = {
		{ "IncludePath", "Framework/LightningEffect.h" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_NiagaraComponent_MetaData[] = {
		{ "Category", "Components" },
		{ "Comment", "/**\n\x09* =============================================================\n\x09*/" },
		{ "EditInline", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Billboard_MetaData[] = {
		{ "Category", "Components" },
		{ "EditInline", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightningEmitter_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Root_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Growth_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bActive_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bIsFadingOut_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightningParams_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_IntensityDef_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "Comment", "/**\n\x09* =============================================================\n\x09* Intensity params (default/current)\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Intensity params (default/current)" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_IntensityCur_MetaData[] = {
		{ "Category", "LightningParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnLightningSpawned_MetaData[] = {
		{ "Category", "LightningEvents" },
		{ "Comment", "/**\n\x09* =============================================================\n\x09* Blueprint assignable events\n\x09*/// Called when lightning is setup with emitter params (analog for BeginPlay event)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Blueprint assignable events\n       // Called when lightning is setup with emitter params (analog for BeginPlay event)" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnLightningSparkMove_MetaData[] = {
		{ "Category", "LightningEvents" },
		{ "Comment", "// Called when lightning spark has moved between Start and End points\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when lightning spark has moved between Start and End points" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnLightningSparkEndMove_MetaData[] = {
		{ "Category", "LightningEvents" },
		{ "Comment", "// Called when lightning spark has reached Target Attachment point (lightning is fully formed)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when lightning spark has reached Target Attachment point (lightning is fully formed)" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnLightningBranched_MetaData[] = {
		{ "Category", "LightningEvents" },
		{ "Comment", "// Called when lightning is branched\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when lightning is branched" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnIntensityChanged_MetaData[] = {
		{ "Category", "LightningEvents" },
		{ "Comment", "// Called when intensity of lightning is changed (when the lightning is flashing for example)\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when intensity of lightning is changed (when the lightning is flashing for example)" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnLightningOverlap_MetaData[] = {
		{ "Category", "LightningEvents" },
		{ "Comment", "// Called when a lightning overlaps an actor (or several) in the world\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when a lightning overlaps an actor (or several) in the world" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnLightningHit_MetaData[] = {
		{ "Category", "LightningEvents" },
		{ "Comment", "// Called when a lightning hits an actor in the world\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEffect.h" },
		{ "ToolTip", "Called when a lightning hits an actor in the world" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_NiagaraComponent;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Billboard;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_LightningEmitter;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Root;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Growth;
	static void NewProp_bActive_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bActive;
	static void NewProp_bIsFadingOut_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bIsFadingOut;
	static const UECodeGen_Private::FStructPropertyParams NewProp_LightningParams;
	static const UECodeGen_Private::FStructPropertyParams NewProp_IntensityDef;
	static const UECodeGen_Private::FStructPropertyParams NewProp_IntensityCur;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnLightningSpawned;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnLightningSparkMove;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnLightningSparkEndMove;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnLightningBranched;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnIntensityChanged;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnLightningOverlap;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnLightningHit;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static UObject* (*const DependentSingletons[])();
	static constexpr FClassFunctionLinkInfo FuncInfo[] = {
		{ &Z_Construct_UFunction_ALightningEffect_Deactivate, "Deactivate" }, // 3901211092
		{ &Z_Construct_UFunction_ALightningEffect_Discharge, "Discharge" }, // 1554485693
		{ &Z_Construct_UFunction_ALightningEffect_DoCollisionCheck, "DoCollisionCheck" }, // 1529442550
		{ &Z_Construct_UFunction_ALightningEffect_FadeOut, "FadeOut" }, // 2308672572
		{ &Z_Construct_UFunction_ALightningEffect_GetOrder, "GetOrder" }, // 866601716
		{ &Z_Construct_UFunction_ALightningEffect_GetPattern, "GetPattern" }, // 1258860143
		{ &Z_Construct_UFunction_ALightningEffect_IsRoot, "IsRoot" }, // 655554424
		{ &Z_Construct_UFunction_ALightningEffect_OnBoltFlashing, "OnBoltFlashing" }, // 1387300012
		{ &Z_Construct_UFunction_ALightningEffect_OnIntensityChanged, "OnIntensityChanged" }, // 4152185136
		{ &Z_Construct_UFunction_ALightningEffect_OnLightningBranched, "OnLightningBranched" }, // 3290434185
		{ &Z_Construct_UFunction_ALightningEffect_OnLightningHit, "OnLightningHit" }, // 4103424422
		{ &Z_Construct_UFunction_ALightningEffect_OnLightningOverlap, "OnLightningOverlap" }, // 120894074
		{ &Z_Construct_UFunction_ALightningEffect_OnLightningSparkEndMove, "OnLightningSparkEndMove" }, // 1234795238
		{ &Z_Construct_UFunction_ALightningEffect_OnLightningSparkMove, "OnLightningSparkMove" }, // 3390345606
		{ &Z_Construct_UFunction_ALightningEffect_OnLightningSpawned, "OnLightningSpawned" }, // 2073808777
	};
	static_assert(UE_ARRAY_COUNT(FuncInfo) < 2048);
	static constexpr FCppClassTypeInfoStatic StaticCppClassTypeInfo = {
		TCppClassTypeTraits<ALightningEffect>::IsAbstract,
	};
	static const UECodeGen_Private::FClassParams ClassParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_NiagaraComponent = { "NiagaraComponent", nullptr, (EPropertyFlags)0x00100000000a001d, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, NiagaraComponent), Z_Construct_UClass_UNiagaraComponent_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_NiagaraComponent_MetaData), NewProp_NiagaraComponent_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_Billboard = { "Billboard", nullptr, (EPropertyFlags)0x001000000008001d, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, Billboard), Z_Construct_UClass_UBillboardComponent_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Billboard_MetaData), NewProp_Billboard_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_LightningEmitter = { "LightningEmitter", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, LightningEmitter), Z_Construct_UClass_ALightningEmitter_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightningEmitter_MetaData), NewProp_LightningEmitter_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_Root = { "Root", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, Root), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Root_MetaData), NewProp_Root_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_Growth = { "Growth", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, Growth), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Growth_MetaData), NewProp_Growth_MetaData) };
void Z_Construct_UClass_ALightningEffect_Statics::NewProp_bActive_SetBit(void* Obj)
{
	((ALightningEffect*)Obj)->bActive = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_bActive = { "bActive", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEffect), &Z_Construct_UClass_ALightningEffect_Statics::NewProp_bActive_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bActive_MetaData), NewProp_bActive_MetaData) };
void Z_Construct_UClass_ALightningEffect_Statics::NewProp_bIsFadingOut_SetBit(void* Obj)
{
	((ALightningEffect*)Obj)->bIsFadingOut = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_bIsFadingOut = { "bIsFadingOut", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEffect), &Z_Construct_UClass_ALightningEffect_Statics::NewProp_bIsFadingOut_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bIsFadingOut_MetaData), NewProp_bIsFadingOut_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_LightningParams = { "LightningParams", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, LightningParams), Z_Construct_UScriptStruct_FLightningParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightningParams_MetaData), NewProp_LightningParams_MetaData) }; // 2783240090
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_IntensityDef = { "IntensityDef", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, IntensityDef), Z_Construct_UScriptStruct_FLightningIntensityParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_IntensityDef_MetaData), NewProp_IntensityDef_MetaData) }; // 389008404
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_IntensityCur = { "IntensityCur", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, IntensityCur), Z_Construct_UScriptStruct_FLightningIntensityParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_IntensityCur_MetaData), NewProp_IntensityCur_MetaData) }; // 389008404
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningSpawned = { "EventOnLightningSpawned", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, EventOnLightningSpawned), Z_Construct_USparseDelegateFunction_Lightnings_LightningSpawnedSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnLightningSpawned_MetaData), NewProp_EventOnLightningSpawned_MetaData) }; // 3506998835
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningSparkMove = { "EventOnLightningSparkMove", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, EventOnLightningSparkMove), Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkMoveSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnLightningSparkMove_MetaData), NewProp_EventOnLightningSparkMove_MetaData) }; // 1441909938
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningSparkEndMove = { "EventOnLightningSparkEndMove", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, EventOnLightningSparkEndMove), Z_Construct_USparseDelegateFunction_Lightnings_LightningSparkEndMoveSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnLightningSparkEndMove_MetaData), NewProp_EventOnLightningSparkEndMove_MetaData) }; // 2407263731
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningBranched = { "EventOnLightningBranched", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, EventOnLightningBranched), Z_Construct_USparseDelegateFunction_Lightnings_LightningBranchedSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnLightningBranched_MetaData), NewProp_EventOnLightningBranched_MetaData) }; // 2726084466
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnIntensityChanged = { "EventOnIntensityChanged", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, EventOnIntensityChanged), Z_Construct_USparseDelegateFunction_Lightnings_IntensityChangedSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnIntensityChanged_MetaData), NewProp_EventOnIntensityChanged_MetaData) }; // 2794166724
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningOverlap = { "EventOnLightningOverlap", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, EventOnLightningOverlap), Z_Construct_USparseDelegateFunction_Lightnings_LightningOverlapSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnLightningOverlap_MetaData), NewProp_EventOnLightningOverlap_MetaData) }; // 2694925162
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningHit = { "EventOnLightningHit", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEffect, EventOnLightningHit), Z_Construct_USparseDelegateFunction_Lightnings_LightningHitSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnLightningHit_MetaData), NewProp_EventOnLightningHit_MetaData) }; // 2517288971
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UClass_ALightningEffect_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_NiagaraComponent,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_Billboard,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_LightningEmitter,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_Root,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_Growth,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_bActive,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_bIsFadingOut,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_LightningParams,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_IntensityDef,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_IntensityCur,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningSpawned,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningSparkMove,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningSparkEndMove,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningBranched,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnIntensityChanged,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningOverlap,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEffect_Statics::NewProp_EventOnLightningHit,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEffect_Statics::PropPointers) < 2048);
UObject* (*const Z_Construct_UClass_ALightningEffect_Statics::DependentSingletons[])() = {
	(UObject* (*)())Z_Construct_UClass_AActor,
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEffect_Statics::DependentSingletons) < 16);
const UECodeGen_Private::FClassParams Z_Construct_UClass_ALightningEffect_Statics::ClassParams = {
	&ALightningEffect::StaticClass,
	"Engine",
	&StaticCppClassTypeInfo,
	DependentSingletons,
	FuncInfo,
	Z_Construct_UClass_ALightningEffect_Statics::PropPointers,
	nullptr,
	UE_ARRAY_COUNT(DependentSingletons),
	UE_ARRAY_COUNT(FuncInfo),
	UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEffect_Statics::PropPointers),
	0,
	0x009000A4u,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEffect_Statics::Class_MetaDataParams), Z_Construct_UClass_ALightningEffect_Statics::Class_MetaDataParams)
};
UClass* Z_Construct_UClass_ALightningEffect()
{
	if (!Z_Registration_Info_UClass_ALightningEffect.OuterSingleton)
	{
		UECodeGen_Private::ConstructUClass(Z_Registration_Info_UClass_ALightningEffect.OuterSingleton, Z_Construct_UClass_ALightningEffect_Statics::ClassParams);
	}
	return Z_Registration_Info_UClass_ALightningEffect.OuterSingleton;
}
template<> LIGHTNINGS_API UClass* StaticClass<ALightningEffect>()
{
	return ALightningEffect::StaticClass();
}
DEFINE_VTABLE_PTR_HELPER_CTOR(ALightningEffect);
ALightningEffect::~ALightningEffect() {}
// End Class ALightningEffect

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_Statics
{
	static constexpr FStructRegisterCompiledInInfo ScriptStructInfo[] = {
		{ FLightningIntensityParams::StaticStruct, Z_Construct_UScriptStruct_FLightningIntensityParams_Statics::NewStructOps, TEXT("LightningIntensityParams"), &Z_Registration_Info_UScriptStruct_LightningIntensityParams, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FLightningIntensityParams), 389008404U) },
	};
	static constexpr FClassRegisterCompiledInInfo ClassInfo[] = {
		{ Z_Construct_UClass_ALightningEffect, ALightningEffect::StaticClass, TEXT("ALightningEffect"), &Z_Registration_Info_UClass_ALightningEffect, CONSTRUCT_RELOAD_VERSION_INFO(FClassReloadVersionInfo, sizeof(ALightningEffect), 3425564293U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_44572638(TEXT("/Script/Lightnings"),
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_Statics::ClassInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_Statics::ClassInfo),
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_Statics::ScriptStructInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_Statics::ScriptStructInfo),
	nullptr, 0);
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
