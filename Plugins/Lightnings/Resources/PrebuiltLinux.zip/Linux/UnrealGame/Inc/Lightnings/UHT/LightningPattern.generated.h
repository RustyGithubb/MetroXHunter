// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

// IWYU pragma: private, include "Framework/LightningPattern.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS
struct FLightningPattern;
#ifdef LIGHTNINGS_LightningPattern_generated_h
#error "LightningPattern.generated.h already included, missing '#pragma once' in LightningPattern.h"
#endif
#define LIGHTNINGS_LightningPattern_generated_h

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_19_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FLightningSparkData_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FLightningSparkData>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_48_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FLightningPattern_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FLightningPattern>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_101_RPC_WRAPPERS_NO_PURE_DECLS \
	DECLARE_FUNCTION(execGetMiddlePoint); \
	DECLARE_FUNCTION(execGetEndPoint); \
	DECLARE_FUNCTION(execGetStartPoint); \
	DECLARE_FUNCTION(execGetPoint);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_101_INCLASS_NO_PURE_DECLS \
private: \
	static void StaticRegisterNativesULightningPatternLib(); \
	friend struct Z_Construct_UClass_ULightningPatternLib_Statics; \
public: \
	DECLARE_CLASS(ULightningPatternLib, UBlueprintFunctionLibrary, COMPILED_IN_FLAGS(0), CASTCLASS_None, TEXT("/Script/Lightnings"), NO_API) \
	DECLARE_SERIALIZER(ULightningPatternLib)


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_101_ENHANCED_CONSTRUCTORS \
	/** Standard constructor, called after all reflected properties have been initialized */ \
	NO_API ULightningPatternLib(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get()); \
private: \
	/** Private move- and copy-constructors, should never be used */ \
	ULightningPatternLib(ULightningPatternLib&&); \
	ULightningPatternLib(const ULightningPatternLib&); \
public: \
	DECLARE_VTABLE_PTR_HELPER_CTOR(NO_API, ULightningPatternLib); \
	DEFINE_VTABLE_PTR_HELPER_CTOR_CALLER(ULightningPatternLib); \
	DEFINE_DEFAULT_OBJECT_INITIALIZER_CONSTRUCTOR_CALL(ULightningPatternLib) \
	NO_API virtual ~ULightningPatternLib();


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_98_PROLOG
#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_101_GENERATED_BODY \
PRAGMA_DISABLE_DEPRECATION_WARNINGS \
public: \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_101_RPC_WRAPPERS_NO_PURE_DECLS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_101_INCLASS_NO_PURE_DECLS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_101_ENHANCED_CONSTRUCTORS \
private: \
PRAGMA_ENABLE_DEPRECATION_WARNINGS


template<> LIGHTNINGS_API UClass* StaticClass<class ULightningPatternLib>();

#undef CURRENT_FILE_ID
#define CURRENT_FILE_ID FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h


PRAGMA_ENABLE_DEPRECATION_WARNINGS
