// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

// IWYU pragma: private, include "Framework/LightningEmitter.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS
class ALightningEffect;
#ifdef LIGHTNINGS_LightningEmitter_generated_h
#error "LightningEmitter.generated.h already included, missing '#pragma once' in LightningEmitter.h"
#endif
#define LIGHTNINGS_LightningEmitter_generated_h

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_21_DELEGATE \
LIGHTNINGS_API void FRootSpawnedSignature_DelegateWrapper(const FMulticastScriptDelegate& RootSpawnedSignature, ALightningEffect* Root);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_28_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FLightningSetupParams_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FLightningSetupParams>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_RPC_WRAPPERS_NO_PURE_DECLS \
	virtual void RequestSpawnLightning_Implementation(int32 Seed); \
	virtual void ResetGenerator_Implementation(); \
	virtual void DeactivateEmitter_Implementation(); \
	DECLARE_FUNCTION(execRequestSpawnLightning); \
	DECLARE_FUNCTION(execOnRootSpawned); \
	DECLARE_FUNCTION(execIsEmitterActive); \
	DECLARE_FUNCTION(execHasAnyLightnings); \
	DECLARE_FUNCTION(execGetLightningsNum); \
	DECLARE_FUNCTION(execResetGenerator); \
	DECLARE_FUNCTION(execDeactivateEmitter); \
	DECLARE_FUNCTION(execActivateEmitter);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_CALLBACK_WRAPPERS
#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_INCLASS_NO_PURE_DECLS \
private: \
	static void StaticRegisterNativesALightningEmitter(); \
	friend struct Z_Construct_UClass_ALightningEmitter_Statics; \
public: \
	DECLARE_CLASS(ALightningEmitter, AActor, COMPILED_IN_FLAGS(0 | CLASS_Config), CASTCLASS_None, TEXT("/Script/Lightnings"), NO_API) \
	DECLARE_SERIALIZER(ALightningEmitter) \
	enum class ENetFields_Private : uint16 \
	{ \
		NETFIELD_REP_START=(uint16)((int32)Super::ENetFields_Private::NETFIELD_REP_END + (int32)1), \
		bAutoActivate=NETFIELD_REP_START, \
		bLoop, \
		LoopDuration, \
		SourceAttachment, \
		TargetAttachment, \
		LightningParams, \
		BranchingParams, \
		RootEmissionParams, \
		BranchEmissionParams, \
		DisplacementMult, \
		TimeMultiplier, \
		bUseSeparateThread, \
		bGenerateHitEvents, \
		HitReaction, \
		bGenerateOverlapEvents, \
		IgnoredActors, \
		NETFIELD_REP_END=IgnoredActors	}; \
	NO_API virtual void ValidateGeneratedRepEnums(const TArray<struct FRepRecord>& ClassReps) const override;


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_ENHANCED_CONSTRUCTORS \
private: \
	/** Private move- and copy-constructors, should never be used */ \
	ALightningEmitter(ALightningEmitter&&); \
	ALightningEmitter(const ALightningEmitter&); \
public: \
	DECLARE_VTABLE_PTR_HELPER_CTOR(NO_API, ALightningEmitter); \
	DEFINE_VTABLE_PTR_HELPER_CTOR_CALLER(ALightningEmitter); \
	DEFINE_DEFAULT_CONSTRUCTOR_CALL(ALightningEmitter) \
	NO_API virtual ~ALightningEmitter();


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_37_PROLOG
#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_GENERATED_BODY \
PRAGMA_DISABLE_DEPRECATION_WARNINGS \
public: \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_RPC_WRAPPERS_NO_PURE_DECLS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_CALLBACK_WRAPPERS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_INCLASS_NO_PURE_DECLS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_40_ENHANCED_CONSTRUCTORS \
private: \
PRAGMA_ENABLE_DEPRECATION_WARNINGS


template<> LIGHTNINGS_API UClass* StaticClass<class ALightningEmitter>();

#undef CURRENT_FILE_ID
#define CURRENT_FILE_ID FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h


PRAGMA_ENABLE_DEPRECATION_WARNINGS
