// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

// IWYU pragma: private, include "Parameters/EmissionParams.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS
#ifdef LIGHTNINGS_EmissionParams_generated_h
#error "EmissionParams.generated.h already included, missing '#pragma once' in EmissionParams.h"
#endif
#define LIGHTNINGS_EmissionParams_generated_h

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_EmissionParams_h_11_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FEmissionParams_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FEmissionParams>();

#undef CURRENT_FILE_ID
#define CURRENT_FILE_ID FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_EmissionParams_h


PRAGMA_ENABLE_DEPRECATION_WARNINGS
