// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Parameters/BranchingParams.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeBranchingParams() {}

// Begin Cross Module References
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FFloatRange();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FBranchingParams();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin ScriptStruct FBranchingParams
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_BranchingParams;
class UScriptStruct* FBranchingParams::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_BranchingParams.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_BranchingParams.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FBranchingParams, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("BranchingParams"));
	}
	return Z_Registration_Info_UScriptStruct_BranchingParams.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FBranchingParams>()
{
	return FBranchingParams::StaticStruct();
}
struct Z_Construct_UScriptStruct_FBranchingParams_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BranchChance_MetaData[] = {
		{ "Category", "LightningBranching" },
		{ "Comment", "// Lightning branch probability\n" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
		{ "ToolTip", "Lightning branch probability" },
		{ "UIMax", "1.0" },
		{ "UIMin", "0.0" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BranchChanceFading_MetaData[] = {
		{ "Category", "LightningBranching" },
		{ "Comment", "// Fading of BranchChance value with order of lightning\n" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
		{ "ToolTip", "Fading of BranchChance value with order of lightning" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_RotationRange_MetaData[] = {
		{ "Category", "LightningBranching" },
		{ "Comment", "// Branch direction offset in degrees\n" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
		{ "ToolTip", "Branch direction offset in degrees" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LengthRange_MetaData[] = {
		{ "Category", "LightningBranching" },
		{ "Comment", "/**\n\x09* Distance between start point and end point of a branch in cm\n\x09* This value gets multiplied by length of root lightning\n\x09*/" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
		{ "ToolTip", "Distance between start point and end point of a branch in cm\nThis value gets multiplied by length of root lightning" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_ConvergeFactor_MetaData[] = {
		{ "Category", "LightningBranching" },
		{ "Comment", "/**\n\x09 * Defines a multiplier of branches convergence to a lightning target point\n\x09 * \n\x09 * 0.0 - no convergence (branches are directed out of the lightning root)\n\x09 * 1.0 - full convergence (branches are directed to a lightning target)\n\x09 */" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
		{ "ToolTip", "Defines a multiplier of branches convergence to a lightning target point\n\n0.0 - no convergence (branches are directed out of the lightning root)\n1.0 - full convergence (branches are directed to a lightning target)" },
		{ "UIMax", "1.0" },
		{ "UIMin", "0.0" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bUseBranchesLimit_MetaData[] = {
		{ "Category", "LightningBranching" },
		{ "Comment", "/**\n\x09* Whether emitter use BranchesLimit parameter\n\x09*/" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
		{ "ToolTip", "Whether emitter use BranchesLimit parameter" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BranchesLimit_MetaData[] = {
		{ "Category", "LightningBranching" },
		{ "Comment", "/**\n\x09* Max branches count\n\x09*/" },
		{ "EditCondition", "bUseBranchesLimit == true" },
		{ "ModuleRelativePath", "Public/Parameters/BranchingParams.h" },
		{ "ToolTip", "Max branches count" },
		{ "UIMin", "0" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFloatPropertyParams NewProp_BranchChance;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_BranchChanceFading;
	static const UECodeGen_Private::FStructPropertyParams NewProp_RotationRange;
	static const UECodeGen_Private::FStructPropertyParams NewProp_LengthRange;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_ConvergeFactor;
	static void NewProp_bUseBranchesLimit_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bUseBranchesLimit;
	static const UECodeGen_Private::FIntPropertyParams NewProp_BranchesLimit;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FBranchingParams>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_BranchChance = { "BranchChance", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FBranchingParams, BranchChance), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BranchChance_MetaData), NewProp_BranchChance_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_BranchChanceFading = { "BranchChanceFading", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FBranchingParams, BranchChanceFading), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BranchChanceFading_MetaData), NewProp_BranchChanceFading_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_RotationRange = { "RotationRange", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FBranchingParams, RotationRange), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_RotationRange_MetaData), NewProp_RotationRange_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_LengthRange = { "LengthRange", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FBranchingParams, LengthRange), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LengthRange_MetaData), NewProp_LengthRange_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_ConvergeFactor = { "ConvergeFactor", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FBranchingParams, ConvergeFactor), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_ConvergeFactor_MetaData), NewProp_ConvergeFactor_MetaData) };
void Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_bUseBranchesLimit_SetBit(void* Obj)
{
	((FBranchingParams*)Obj)->bUseBranchesLimit = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_bUseBranchesLimit = { "bUseBranchesLimit", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(FBranchingParams), &Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_bUseBranchesLimit_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bUseBranchesLimit_MetaData), NewProp_bUseBranchesLimit_MetaData) };
const UECodeGen_Private::FIntPropertyParams Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_BranchesLimit = { "BranchesLimit", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FBranchingParams, BranchesLimit), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BranchesLimit_MetaData), NewProp_BranchesLimit_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FBranchingParams_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_BranchChance,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_BranchChanceFading,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_RotationRange,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_LengthRange,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_ConvergeFactor,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_bUseBranchesLimit,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FBranchingParams_Statics::NewProp_BranchesLimit,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FBranchingParams_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FBranchingParams_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"BranchingParams",
	Z_Construct_UScriptStruct_FBranchingParams_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FBranchingParams_Statics::PropPointers),
	sizeof(FBranchingParams),
	alignof(FBranchingParams),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FBranchingParams_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FBranchingParams_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FBranchingParams()
{
	if (!Z_Registration_Info_UScriptStruct_BranchingParams.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_BranchingParams.InnerSingleton, Z_Construct_UScriptStruct_FBranchingParams_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_BranchingParams.InnerSingleton;
}
// End ScriptStruct FBranchingParams

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_BranchingParams_h_Statics
{
	static constexpr FStructRegisterCompiledInInfo ScriptStructInfo[] = {
		{ FBranchingParams::StaticStruct, Z_Construct_UScriptStruct_FBranchingParams_Statics::NewStructOps, TEXT("BranchingParams"), &Z_Registration_Info_UScriptStruct_BranchingParams, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FBranchingParams), 2555318798U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_BranchingParams_h_3388339257(TEXT("/Script/Lightnings"),
	nullptr, 0,
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_BranchingParams_h_Statics::ScriptStructInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_BranchingParams_h_Statics::ScriptStructInfo),
	nullptr, 0);
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
