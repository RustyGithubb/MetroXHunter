// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Framework/LightningEmitter.h"
#include "Lightnings/Public/Framework/LightningAttachment.h"
#include "Lightnings/Public/Parameters/BranchingParams.h"
#include "Lightnings/Public/Parameters/EmissionParams.h"
#include "Lightnings/Public/Parameters/LightningParams.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeLightningEmitter() {}

// Begin Cross Module References
COREUOBJECT_API UClass* Z_Construct_UClass_UClass();
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FColor();
ENGINE_API UClass* Z_Construct_UClass_AActor();
ENGINE_API UClass* Z_Construct_UClass_AActor_NoRegister();
ENGINE_API UClass* Z_Construct_UClass_UBillboardComponent_NoRegister();
ENGINE_API UEnum* Z_Construct_UEnum_Engine_ECollisionChannel();
ENGINE_API UEnum* Z_Construct_UEnum_Engine_ECollisionResponse();
LIGHTNINGS_API UClass* Z_Construct_UClass_ALightningEffect_NoRegister();
LIGHTNINGS_API UClass* Z_Construct_UClass_ALightningEmitter();
LIGHTNINGS_API UClass* Z_Construct_UClass_ALightningEmitter_NoRegister();
LIGHTNINGS_API UEnum* Z_Construct_UEnum_Lightnings_EHitReaction();
LIGHTNINGS_API UFunction* Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FBranchingParams();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FEmissionParams();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningAttachment();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningParams();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningSetupParams();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin Delegate FRootSpawnedSignature
struct Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics
{
	struct _Script_Lightnings_eventRootSpawnedSignature_Parms
	{
		ALightningEffect* Root;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Root;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::NewProp_Root = { "Root", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(_Script_Lightnings_eventRootSpawnedSignature_Parms, Root), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::NewProp_Root,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::FuncParams = { (UObject*(*)())Z_Construct_UPackage__Script_Lightnings, nullptr, "RootSpawnedSignature__DelegateSignature", "LightningEmitter", "EventOnRootSpawned", Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::PropPointers), sizeof(Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::_Script_Lightnings_eventRootSpawnedSignature_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00130000, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::Function_MetaDataParams), Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::_Script_Lightnings_eventRootSpawnedSignature_Parms) < MAX_uint16);
UFunction* Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature_Statics::FuncParams);
	}
	return ReturnFunction;
}
void FRootSpawnedSignature_DelegateWrapper(const FMulticastScriptDelegate& RootSpawnedSignature, ALightningEffect* Root)
{
	struct _Script_Lightnings_eventRootSpawnedSignature_Parms
	{
		ALightningEffect* Root;
	};
	_Script_Lightnings_eventRootSpawnedSignature_Parms Parms;
	Parms.Root=Root;
	RootSpawnedSignature.ProcessMulticastDelegate<UObject>(&Parms);
}
// End Delegate FRootSpawnedSignature

// Begin ScriptStruct FLightningSetupParams
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_LightningSetupParams;
class UScriptStruct* FLightningSetupParams::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_LightningSetupParams.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_LightningSetupParams.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FLightningSetupParams, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("LightningSetupParams"));
	}
	return Z_Registration_Info_UScriptStruct_LightningSetupParams.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FLightningSetupParams>()
{
	return FLightningSetupParams::StaticStruct();
}
struct Z_Construct_UScriptStruct_FLightningSetupParams_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
#endif // WITH_METADATA
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FLightningSetupParams>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FLightningSetupParams_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"LightningSetupParams",
	nullptr,
	0,
	sizeof(FLightningSetupParams),
	alignof(FLightningSetupParams),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningSetupParams_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FLightningSetupParams_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FLightningSetupParams()
{
	if (!Z_Registration_Info_UScriptStruct_LightningSetupParams.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_LightningSetupParams.InnerSingleton, Z_Construct_UScriptStruct_FLightningSetupParams_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_LightningSetupParams.InnerSingleton;
}
// End ScriptStruct FLightningSetupParams

// Begin Class ALightningEmitter Function ActivateEmitter
struct LightningEmitter_eventActivateEmitter_Parms
{
	bool bReset;
};
static FName NAME_ALightningEmitter_ActivateEmitter = FName(TEXT("ActivateEmitter"));
void ALightningEmitter::ActivateEmitter(bool bReset)
{
	LightningEmitter_eventActivateEmitter_Parms Parms;
	Parms.bReset=bReset ? true : false;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEmitter_ActivateEmitter),&Parms);
}
struct Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningEmitter" },
		{ "Comment", "/**\n\x09* Runs lightnings emitter\n\x09* \n\x09* @param Reset - calls ResetGenerator if true\n\x09*/" },
		{ "CPP_Default_bReset", "false" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Runs lightnings emitter\n\n@param Reset - calls ResetGenerator if true" },
	};
#endif // WITH_METADATA
	static void NewProp_bReset_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bReset;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
void Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::NewProp_bReset_SetBit(void* Obj)
{
	((LightningEmitter_eventActivateEmitter_Parms*)Obj)->bReset = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::NewProp_bReset = { "bReset", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(LightningEmitter_eventActivateEmitter_Parms), &Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::NewProp_bReset_SetBit, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::NewProp_bReset,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "ActivateEmitter", nullptr, nullptr, Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::PropPointers), sizeof(LightningEmitter_eventActivateEmitter_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x04024CC0, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEmitter_eventActivateEmitter_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEmitter_ActivateEmitter()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_ActivateEmitter_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execActivateEmitter)
{
	P_GET_UBOOL(Z_Param_bReset);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->ActivateEmitter_Implementation(Z_Param_bReset);
	P_NATIVE_END;
}
// End Class ALightningEmitter Function ActivateEmitter

// Begin Class ALightningEmitter Function DeactivateEmitter
static FName NAME_ALightningEmitter_DeactivateEmitter = FName(TEXT("DeactivateEmitter"));
void ALightningEmitter::DeactivateEmitter()
{
	ProcessEvent(FindFunctionChecked(NAME_ALightningEmitter_DeactivateEmitter),NULL);
}
struct Z_Construct_UFunction_ALightningEmitter_DeactivateEmitter_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningEmitter" },
		{ "Comment", "/**\n\x09* Removes all associated lightnings and stops spawning loop if it is running\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Removes all associated lightnings and stops spawning loop if it is running" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_DeactivateEmitter_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "DeactivateEmitter", nullptr, nullptr, nullptr, 0, 0, RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x04024CC0, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_DeactivateEmitter_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_DeactivateEmitter_Statics::Function_MetaDataParams) };
UFunction* Z_Construct_UFunction_ALightningEmitter_DeactivateEmitter()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_DeactivateEmitter_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execDeactivateEmitter)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->DeactivateEmitter_Implementation();
	P_NATIVE_END;
}
// End Class ALightningEmitter Function DeactivateEmitter

// Begin Class ALightningEmitter Function GetLightningsNum
struct Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics
{
	struct LightningEmitter_eventGetLightningsNum_Parms
	{
		int32 ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningEmitter" },
		{ "Comment", "/**\n\x09* Returns a number of currently active lightnings\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Returns a number of currently active lightnings" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FIntPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FIntPropertyParams Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEmitter_eventGetLightningsNum_Parms, ReturnValue), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "GetLightningsNum", nullptr, nullptr, Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::LightningEmitter_eventGetLightningsNum_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x14020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::LightningEmitter_eventGetLightningsNum_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEmitter_GetLightningsNum()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_GetLightningsNum_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execGetLightningsNum)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	*(int32*)Z_Param__Result=P_THIS->GetLightningsNum();
	P_NATIVE_END;
}
// End Class ALightningEmitter Function GetLightningsNum

// Begin Class ALightningEmitter Function HasAnyLightnings
struct Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics
{
	struct LightningEmitter_eventHasAnyLightnings_Parms
	{
		bool ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningEmitter" },
		{ "Comment", "/**\n\x09* Returns true if there are any lightnings spawned by the emitter\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Returns true if there are any lightnings spawned by the emitter" },
	};
#endif // WITH_METADATA
	static void NewProp_ReturnValue_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
void Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::NewProp_ReturnValue_SetBit(void* Obj)
{
	((LightningEmitter_eventHasAnyLightnings_Parms*)Obj)->ReturnValue = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(LightningEmitter_eventHasAnyLightnings_Parms), &Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::NewProp_ReturnValue_SetBit, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "HasAnyLightnings", nullptr, nullptr, Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::LightningEmitter_eventHasAnyLightnings_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x14020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::LightningEmitter_eventHasAnyLightnings_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execHasAnyLightnings)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	*(bool*)Z_Param__Result=P_THIS->HasAnyLightnings();
	P_NATIVE_END;
}
// End Class ALightningEmitter Function HasAnyLightnings

// Begin Class ALightningEmitter Function IsEmitterActive
struct Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics
{
	struct LightningEmitter_eventIsEmitterActive_Parms
	{
		bool ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningEmitter" },
		{ "Comment", "/**\n\x09* Returns true if emitter's loop is active\n\x09* or there are any lightnings spawned by the emitter\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Returns true if emitter's loop is active\nor there are any lightnings spawned by the emitter" },
	};
#endif // WITH_METADATA
	static void NewProp_ReturnValue_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
void Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::NewProp_ReturnValue_SetBit(void* Obj)
{
	((LightningEmitter_eventIsEmitterActive_Parms*)Obj)->ReturnValue = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(LightningEmitter_eventIsEmitterActive_Parms), &Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::NewProp_ReturnValue_SetBit, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "IsEmitterActive", nullptr, nullptr, Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::PropPointers), sizeof(Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::LightningEmitter_eventIsEmitterActive_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x14020401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::LightningEmitter_eventIsEmitterActive_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEmitter_IsEmitterActive()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_IsEmitterActive_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execIsEmitterActive)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	*(bool*)Z_Param__Result=P_THIS->IsEmitterActive();
	P_NATIVE_END;
}
// End Class ALightningEmitter Function IsEmitterActive

// Begin Class ALightningEmitter Function OnRootSpawned
struct LightningEmitter_eventOnRootSpawned_Parms
{
	ALightningEffect* Root;
};
static FName NAME_ALightningEmitter_OnRootSpawned = FName(TEXT("OnRootSpawned"));
void ALightningEmitter::OnRootSpawned(ALightningEffect* Root)
{
	LightningEmitter_eventOnRootSpawned_Parms Parms;
	Parms.Root=Root;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEmitter_OnRootSpawned),&Parms);
}
struct Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "/** \n\x09* =============================================================\n\x09* Runtime Blueprint events\n\x09*/// Called when a new root has been spawned\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Runtime Blueprint events\n       // Called when a new root has been spawned" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Root;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::NewProp_Root = { "Root", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEmitter_eventOnRootSpawned_Parms, Root), Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::NewProp_Root,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "OnRootSpawned", nullptr, nullptr, Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::PropPointers), sizeof(LightningEmitter_eventOnRootSpawned_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x08020C00, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEmitter_eventOnRootSpawned_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEmitter_OnRootSpawned()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_OnRootSpawned_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execOnRootSpawned)
{
	P_GET_OBJECT(ALightningEffect,Z_Param_Root);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->OnRootSpawned_Implementation(Z_Param_Root);
	P_NATIVE_END;
}
// End Class ALightningEmitter Function OnRootSpawned

// Begin Class ALightningEmitter Function RequestSpawnLightning
struct LightningEmitter_eventRequestSpawnLightning_Parms
{
	int32 Seed;
};
static FName NAME_ALightningEmitter_RequestSpawnLightning = FName(TEXT("RequestSpawnLightning"));
void ALightningEmitter::RequestSpawnLightning(int32 Seed)
{
	LightningEmitter_eventRequestSpawnLightning_Parms Parms;
	Parms.Seed=Seed;
	ProcessEvent(FindFunctionChecked(NAME_ALightningEmitter_RequestSpawnLightning),&Parms);
}
struct Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Comment", "/**\n\x09* Request generate a new pattern with the given seed, between two specific points.\n\x09* Then spawn a new lightning actor with the generated pattern.\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Request generate a new pattern with the given seed, between two specific points.\nThen spawn a new lightning actor with the generated pattern." },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FIntPropertyParams NewProp_Seed;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FIntPropertyParams Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::NewProp_Seed = { "Seed", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningEmitter_eventRequestSpawnLightning_Parms, Seed), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::NewProp_Seed,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "RequestSpawnLightning", nullptr, nullptr, Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::PropPointers), sizeof(LightningEmitter_eventRequestSpawnLightning_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x00044CC1, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::Function_MetaDataParams) };
static_assert(sizeof(LightningEmitter_eventRequestSpawnLightning_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execRequestSpawnLightning)
{
	P_GET_PROPERTY(FIntProperty,Z_Param_Seed);
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->RequestSpawnLightning_Implementation(Z_Param_Seed);
	P_NATIVE_END;
}
// End Class ALightningEmitter Function RequestSpawnLightning

// Begin Class ALightningEmitter Function ResetGenerator
static FName NAME_ALightningEmitter_ResetGenerator = FName(TEXT("ResetGenerator"));
void ALightningEmitter::ResetGenerator()
{
	ProcessEvent(FindFunctionChecked(NAME_ALightningEmitter_ResetGenerator),NULL);
}
struct Z_Construct_UFunction_ALightningEmitter_ResetGenerator_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningEmitter" },
		{ "Comment", "/**\n\x09* Resets a random number generator for lightning particles and switches back to RNG sequence begin\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Resets a random number generator for lightning particles and switches back to RNG sequence begin" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ALightningEmitter_ResetGenerator_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ALightningEmitter, nullptr, "ResetGenerator", nullptr, nullptr, nullptr, 0, 0, RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x04024CC0, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ALightningEmitter_ResetGenerator_Statics::Function_MetaDataParams), Z_Construct_UFunction_ALightningEmitter_ResetGenerator_Statics::Function_MetaDataParams) };
UFunction* Z_Construct_UFunction_ALightningEmitter_ResetGenerator()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ALightningEmitter_ResetGenerator_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ALightningEmitter::execResetGenerator)
{
	P_FINISH;
	P_NATIVE_BEGIN;
	P_THIS->ResetGenerator_Implementation();
	P_NATIVE_END;
}
// End Class ALightningEmitter Function ResetGenerator

// Begin Class ALightningEmitter
void ALightningEmitter::StaticRegisterNativesALightningEmitter()
{
	UClass* Class = ALightningEmitter::StaticClass();
	static const FNameNativePtrPair Funcs[] = {
		{ "ActivateEmitter", &ALightningEmitter::execActivateEmitter },
		{ "DeactivateEmitter", &ALightningEmitter::execDeactivateEmitter },
		{ "GetLightningsNum", &ALightningEmitter::execGetLightningsNum },
		{ "HasAnyLightnings", &ALightningEmitter::execHasAnyLightnings },
		{ "IsEmitterActive", &ALightningEmitter::execIsEmitterActive },
		{ "OnRootSpawned", &ALightningEmitter::execOnRootSpawned },
		{ "RequestSpawnLightning", &ALightningEmitter::execRequestSpawnLightning },
		{ "ResetGenerator", &ALightningEmitter::execResetGenerator },
	};
	FNativeFunctionRegistrar::RegisterFunctions(Class, Funcs, UE_ARRAY_COUNT(Funcs));
}
IMPLEMENT_CLASS_NO_AUTO_REGISTRATION(ALightningEmitter);
UClass* Z_Construct_UClass_ALightningEmitter_NoRegister()
{
	return ALightningEmitter::StaticClass();
}
struct Z_Construct_UClass_ALightningEmitter_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Class_MetaDataParams[] = {
		{ "IncludePath", "Framework/LightningEmitter.h" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_MainBillboard_MetaData[] = {
		{ "Category", "Billboards" },
		{ "Comment", "/**\n\x09* =============================================================\n\x09*/" },
		{ "EditInline", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SourcePoint_MetaData[] = {
		{ "Category", "Billboards" },
		{ "EditInline", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_TargetPoint_MetaData[] = {
		{ "Category", "Billboards" },
		{ "EditInline", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bAutoActivate_MetaData[] = {
		{ "Category", "Activation" },
		{ "Comment", "// Auto-activate on BeginPlay\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Auto-activate on BeginPlay" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bLoop_MetaData[] = {
		{ "Category", "Activation" },
		{ "Comment", "// Whether the emitter is looped\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Whether the emitter is looped" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LoopDuration_MetaData[] = {
		{ "Category", "Activation" },
		{ "Comment", "// Loop duration value in seconds\n" },
		{ "EditCondition", "bLoop == true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Loop duration value in seconds" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SourceAttachment_MetaData[] = {
		{ "Category", "Attachment" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_TargetAttachment_MetaData[] = {
		{ "Category", "Attachment" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightningParams_MetaData[] = {
		{ "Category", "GeometrySettings" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BranchingParams_MetaData[] = {
		{ "Category", "GeometrySettings" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_RootEmissionParams_MetaData[] = {
		{ "Category", "VisualSettings" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BranchEmissionParams_MetaData[] = {
		{ "Category", "VisualSettings" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_DisplacementMult_MetaData[] = {
		{ "Category", "VisualSettings" },
		{ "Comment", "/**\n\x09* Particles are scaled with distance to camera increasing\n\x09* to avoid bloom fading out when using TemporalAA.\n\x09* This parameter sets scaling multiplier.\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Particles are scaled with distance to camera increasing\nto avoid bloom fading out when using TemporalAA.\nThis parameter sets scaling multiplier." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_TimeMultiplier_MetaData[] = {
		{ "Category", "SystemSettings" },
		{ "Comment", "/**\n\x09* Permits to speed up or slow down lightning spread process\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Permits to speed up or slow down lightning spread process" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bUseSeparateThread_MetaData[] = {
		{ "Category", "SystemSettings" },
		{ "Comment", "/**\n\x09* Use asynchronous calculation of lightning's pattern\n\x09* (should reduce lags but create spawning delay)\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Use asynchronous calculation of lightning's pattern\n(should reduce lags but create spawning delay)" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bGenerateHitEvents_MetaData[] = {
		{ "Category", "LightningCollision" },
		{ "Comment", "/**\n\x09* =================================================\n\x09* Collision settings\n\x09*/// Whether lightnings will generate hit events\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Collision settings\n       // Whether lightnings will generate hit events" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_HitReaction_MetaData[] = {
		{ "Category", "LightningCollision" },
		{ "Comment", "// How lightning should react on a hit event.\n" },
		{ "EditCondition", "bGenerateHitEvents == true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "How lightning should react on a hit event." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bGenerateOverlapEvents_MetaData[] = {
		{ "Category", "LightningCollision" },
		{ "Comment", "// Whether lightnings will generate overlap events\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Whether lightnings will generate overlap events" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_CollisionResponses_MetaData[] = {
		{ "Category", "LightningCollision" },
		{ "Comment", "// The list of collision responses for specific channels\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "The list of collision responses for specific channels" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_IgnoredActors_MetaData[] = {
		{ "Category", "LightningCollision" },
		{ "Comment", "// The list of actors to ignore while collision checks\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "The list of actors to ignore while collision checks" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bDrawBranches_MetaData[] = {
		{ "Category", "DebugSettings" },
		{ "Comment", "/**\n\x09* =================================================\n\x09* Debug settings\n\x09*/// Whether draw branches of the lightning\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Debug settings\n       // Whether draw branches of the lightning" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bDrawCurveWidth_MetaData[] = {
		{ "Category", "DebugSettings" },
		{ "Comment", "// Whether draw a lightning curve with a width specified in lightning params\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Whether draw a lightning curve with a width specified in lightning params" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bCurveCustomColor_MetaData[] = {
		{ "Category", "DebugSettings" },
		{ "Comment", "// Whether draw a lightning curve with a color specified below\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Whether draw a lightning curve with a color specified below" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_CurveColor_MetaData[] = {
		{ "Category", "DebugSettings" },
		{ "Comment", "// Lightning curve visualization color\n" },
		{ "EditCondition", "bCurveCustomColor == true" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Lightning curve visualization color" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_AttachmentVolumesColor_MetaData[] = {
		{ "Category", "DebugSettings" },
		{ "Comment", "// Attachment volumes visualization color\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Attachment volumes visualization color" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EventOnRootSpawned_MetaData[] = {
		{ "Category", "LightningEmitterEvents" },
		{ "Comment", "/**\n\x09* =============================================================\n\x09* Blueprint assignable events\n\x09*/// Called when a new root has been spawned\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "Blueprint assignable events\n       // Called when a new root has been spawned" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightningEffectClass_MetaData[] = {
		{ "Category", "SystemSettings" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_EmitterSeed_MetaData[] = {
		{ "Category", "SystemSettings" },
		{ "Comment", "/**\n\x09 * A seed for lightnings emitter RNG\n\x09 * The same seed means the same sequence of exactly same lightnings.\n\x09 * -1 means use random seed\n\x09 */" },
		{ "ModuleRelativePath", "Public/Framework/LightningEmitter.h" },
		{ "ToolTip", "A seed for lightnings emitter RNG\nThe same seed means the same sequence of exactly same lightnings.\n-1 means use random seed" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_MainBillboard;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_SourcePoint;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_TargetPoint;
	static void NewProp_bAutoActivate_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bAutoActivate;
	static void NewProp_bLoop_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bLoop;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_LoopDuration;
	static const UECodeGen_Private::FStructPropertyParams NewProp_SourceAttachment;
	static const UECodeGen_Private::FStructPropertyParams NewProp_TargetAttachment;
	static const UECodeGen_Private::FStructPropertyParams NewProp_LightningParams;
	static const UECodeGen_Private::FStructPropertyParams NewProp_BranchingParams;
	static const UECodeGen_Private::FStructPropertyParams NewProp_RootEmissionParams;
	static const UECodeGen_Private::FStructPropertyParams NewProp_BranchEmissionParams;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_DisplacementMult;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_TimeMultiplier;
	static void NewProp_bUseSeparateThread_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bUseSeparateThread;
	static void NewProp_bGenerateHitEvents_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bGenerateHitEvents;
	static const UECodeGen_Private::FBytePropertyParams NewProp_HitReaction_Underlying;
	static const UECodeGen_Private::FEnumPropertyParams NewProp_HitReaction;
	static void NewProp_bGenerateOverlapEvents_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bGenerateOverlapEvents;
	static const UECodeGen_Private::FBytePropertyParams NewProp_CollisionResponses_ValueProp;
	static const UECodeGen_Private::FBytePropertyParams NewProp_CollisionResponses_Key_KeyProp;
	static const UECodeGen_Private::FMapPropertyParams NewProp_CollisionResponses;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_IgnoredActors_Inner;
	static const UECodeGen_Private::FArrayPropertyParams NewProp_IgnoredActors;
	static void NewProp_bDrawBranches_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bDrawBranches;
	static void NewProp_bDrawCurveWidth_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bDrawCurveWidth;
	static void NewProp_bCurveCustomColor_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bCurveCustomColor;
	static const UECodeGen_Private::FStructPropertyParams NewProp_CurveColor;
	static const UECodeGen_Private::FStructPropertyParams NewProp_AttachmentVolumesColor;
	static const UECodeGen_Private::FMulticastDelegatePropertyParams NewProp_EventOnRootSpawned;
	static const UECodeGen_Private::FClassPropertyParams NewProp_LightningEffectClass;
	static const UECodeGen_Private::FIntPropertyParams NewProp_EmitterSeed;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static UObject* (*const DependentSingletons[])();
	static constexpr FClassFunctionLinkInfo FuncInfo[] = {
		{ &Z_Construct_UFunction_ALightningEmitter_ActivateEmitter, "ActivateEmitter" }, // 3647131835
		{ &Z_Construct_UFunction_ALightningEmitter_DeactivateEmitter, "DeactivateEmitter" }, // 2242534002
		{ &Z_Construct_UFunction_ALightningEmitter_GetLightningsNum, "GetLightningsNum" }, // 4003712876
		{ &Z_Construct_UFunction_ALightningEmitter_HasAnyLightnings, "HasAnyLightnings" }, // 1207506239
		{ &Z_Construct_UFunction_ALightningEmitter_IsEmitterActive, "IsEmitterActive" }, // 2854987824
		{ &Z_Construct_UFunction_ALightningEmitter_OnRootSpawned, "OnRootSpawned" }, // 3764395627
		{ &Z_Construct_UFunction_ALightningEmitter_RequestSpawnLightning, "RequestSpawnLightning" }, // 4205099574
		{ &Z_Construct_UFunction_ALightningEmitter_ResetGenerator, "ResetGenerator" }, // 2091587076
	};
	static_assert(UE_ARRAY_COUNT(FuncInfo) < 2048);
	static constexpr FCppClassTypeInfoStatic StaticCppClassTypeInfo = {
		TCppClassTypeTraits<ALightningEmitter>::IsAbstract,
	};
	static const UECodeGen_Private::FClassParams ClassParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_MainBillboard = { "MainBillboard", nullptr, (EPropertyFlags)0x0010000000080009, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, MainBillboard), Z_Construct_UClass_UBillboardComponent_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_MainBillboard_MetaData), NewProp_MainBillboard_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_SourcePoint = { "SourcePoint", nullptr, (EPropertyFlags)0x0010000000080009, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, SourcePoint), Z_Construct_UClass_UBillboardComponent_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SourcePoint_MetaData), NewProp_SourcePoint_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_TargetPoint = { "TargetPoint", nullptr, (EPropertyFlags)0x0010000000080009, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, TargetPoint), Z_Construct_UClass_UBillboardComponent_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_TargetPoint_MetaData), NewProp_TargetPoint_MetaData) };
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bAutoActivate_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bAutoActivate = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bAutoActivate = { "bAutoActivate", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bAutoActivate_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bAutoActivate_MetaData), NewProp_bAutoActivate_MetaData) };
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bLoop_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bLoop = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bLoop = { "bLoop", nullptr, (EPropertyFlags)0x0010000200000025, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bLoop_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bLoop_MetaData), NewProp_bLoop_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_LoopDuration = { "LoopDuration", nullptr, (EPropertyFlags)0x0010000200000025, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, LoopDuration), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LoopDuration_MetaData), NewProp_LoopDuration_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_SourceAttachment = { "SourceAttachment", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, SourceAttachment), Z_Construct_UScriptStruct_FLightningAttachment, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SourceAttachment_MetaData), NewProp_SourceAttachment_MetaData) }; // 4099775772
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_TargetAttachment = { "TargetAttachment", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, TargetAttachment), Z_Construct_UScriptStruct_FLightningAttachment, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_TargetAttachment_MetaData), NewProp_TargetAttachment_MetaData) }; // 4099775772
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_LightningParams = { "LightningParams", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, LightningParams), Z_Construct_UScriptStruct_FLightningParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightningParams_MetaData), NewProp_LightningParams_MetaData) }; // 2783240090
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_BranchingParams = { "BranchingParams", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, BranchingParams), Z_Construct_UScriptStruct_FBranchingParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BranchingParams_MetaData), NewProp_BranchingParams_MetaData) }; // 2555318798
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_RootEmissionParams = { "RootEmissionParams", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, RootEmissionParams), Z_Construct_UScriptStruct_FEmissionParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_RootEmissionParams_MetaData), NewProp_RootEmissionParams_MetaData) }; // 1216152273
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_BranchEmissionParams = { "BranchEmissionParams", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, BranchEmissionParams), Z_Construct_UScriptStruct_FEmissionParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BranchEmissionParams_MetaData), NewProp_BranchEmissionParams_MetaData) }; // 1216152273
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_DisplacementMult = { "DisplacementMult", nullptr, (EPropertyFlags)0x0010000200000025, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, DisplacementMult), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_DisplacementMult_MetaData), NewProp_DisplacementMult_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_TimeMultiplier = { "TimeMultiplier", nullptr, (EPropertyFlags)0x0010000200000025, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, TimeMultiplier), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_TimeMultiplier_MetaData), NewProp_TimeMultiplier_MetaData) };
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bUseSeparateThread_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bUseSeparateThread = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bUseSeparateThread = { "bUseSeparateThread", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bUseSeparateThread_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bUseSeparateThread_MetaData), NewProp_bUseSeparateThread_MetaData) };
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateHitEvents_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bGenerateHitEvents = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateHitEvents = { "bGenerateHitEvents", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateHitEvents_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bGenerateHitEvents_MetaData), NewProp_bGenerateHitEvents_MetaData) };
const UECodeGen_Private::FBytePropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_HitReaction_Underlying = { "UnderlyingType", nullptr, (EPropertyFlags)0x0000000000000000, UECodeGen_Private::EPropertyGenFlags::Byte, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, nullptr, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FEnumPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_HitReaction = { "HitReaction", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Enum, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, HitReaction), Z_Construct_UEnum_Lightnings_EHitReaction, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_HitReaction_MetaData), NewProp_HitReaction_MetaData) }; // 2298368100
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateOverlapEvents_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bGenerateOverlapEvents = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateOverlapEvents = { "bGenerateOverlapEvents", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateOverlapEvents_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bGenerateOverlapEvents_MetaData), NewProp_bGenerateOverlapEvents_MetaData) };
const UECodeGen_Private::FBytePropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CollisionResponses_ValueProp = { "CollisionResponses", nullptr, (EPropertyFlags)0x0000000000000001, UECodeGen_Private::EPropertyGenFlags::Byte, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 1, Z_Construct_UEnum_Engine_ECollisionResponse, METADATA_PARAMS(0, nullptr) }; // 1009580041
const UECodeGen_Private::FBytePropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CollisionResponses_Key_KeyProp = { "CollisionResponses_Key", nullptr, (EPropertyFlags)0x0000000000000001, UECodeGen_Private::EPropertyGenFlags::Byte, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, Z_Construct_UEnum_Engine_ECollisionChannel, METADATA_PARAMS(0, nullptr) }; // 756624936
const UECodeGen_Private::FMapPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CollisionResponses = { "CollisionResponses", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Map, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, CollisionResponses), EMapPropertyFlags::None, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_CollisionResponses_MetaData), NewProp_CollisionResponses_MetaData) }; // 756624936 1009580041
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_IgnoredActors_Inner = { "IgnoredActors", nullptr, (EPropertyFlags)0x0000000000000000, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, Z_Construct_UClass_AActor_NoRegister, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FArrayPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_IgnoredActors = { "IgnoredActors", nullptr, (EPropertyFlags)0x0010000000000025, UECodeGen_Private::EPropertyGenFlags::Array, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, IgnoredActors), EArrayPropertyFlags::None, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_IgnoredActors_MetaData), NewProp_IgnoredActors_MetaData) };
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawBranches_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bDrawBranches = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawBranches = { "bDrawBranches", nullptr, (EPropertyFlags)0x0010000000000001, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawBranches_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bDrawBranches_MetaData), NewProp_bDrawBranches_MetaData) };
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawCurveWidth_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bDrawCurveWidth = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawCurveWidth = { "bDrawCurveWidth", nullptr, (EPropertyFlags)0x0010000000000001, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawCurveWidth_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bDrawCurveWidth_MetaData), NewProp_bDrawCurveWidth_MetaData) };
void Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bCurveCustomColor_SetBit(void* Obj)
{
	((ALightningEmitter*)Obj)->bCurveCustomColor = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bCurveCustomColor = { "bCurveCustomColor", nullptr, (EPropertyFlags)0x0010000000000001, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(ALightningEmitter), &Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bCurveCustomColor_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bCurveCustomColor_MetaData), NewProp_bCurveCustomColor_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CurveColor = { "CurveColor", nullptr, (EPropertyFlags)0x0010000000000001, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, CurveColor), Z_Construct_UScriptStruct_FColor, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_CurveColor_MetaData), NewProp_CurveColor_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_AttachmentVolumesColor = { "AttachmentVolumesColor", nullptr, (EPropertyFlags)0x0010000000000001, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, AttachmentVolumesColor), Z_Construct_UScriptStruct_FColor, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_AttachmentVolumesColor_MetaData), NewProp_AttachmentVolumesColor_MetaData) };
const UECodeGen_Private::FMulticastDelegatePropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_EventOnRootSpawned = { "EventOnRootSpawned", nullptr, (EPropertyFlags)0x0010000010080000, UECodeGen_Private::EPropertyGenFlags::SparseMulticastDelegate, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, EventOnRootSpawned), Z_Construct_USparseDelegateFunction_Lightnings_RootSpawnedSignature__DelegateSignature, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EventOnRootSpawned_MetaData), NewProp_EventOnRootSpawned_MetaData) }; // 3272980753
const UECodeGen_Private::FClassPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_LightningEffectClass = { "LightningEffectClass", nullptr, (EPropertyFlags)0x0044000000000001, UECodeGen_Private::EPropertyGenFlags::Class, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, LightningEffectClass), Z_Construct_UClass_UClass, Z_Construct_UClass_ALightningEffect_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightningEffectClass_MetaData), NewProp_LightningEffectClass_MetaData) };
const UECodeGen_Private::FIntPropertyParams Z_Construct_UClass_ALightningEmitter_Statics::NewProp_EmitterSeed = { "EmitterSeed", nullptr, (EPropertyFlags)0x0040000000000001, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(ALightningEmitter, EmitterSeed), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_EmitterSeed_MetaData), NewProp_EmitterSeed_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UClass_ALightningEmitter_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_MainBillboard,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_SourcePoint,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_TargetPoint,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bAutoActivate,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bLoop,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_LoopDuration,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_SourceAttachment,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_TargetAttachment,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_LightningParams,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_BranchingParams,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_RootEmissionParams,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_BranchEmissionParams,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_DisplacementMult,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_TimeMultiplier,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bUseSeparateThread,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateHitEvents,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_HitReaction_Underlying,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_HitReaction,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bGenerateOverlapEvents,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CollisionResponses_ValueProp,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CollisionResponses_Key_KeyProp,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CollisionResponses,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_IgnoredActors_Inner,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_IgnoredActors,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawBranches,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bDrawCurveWidth,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_bCurveCustomColor,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_CurveColor,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_AttachmentVolumesColor,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_EventOnRootSpawned,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_LightningEffectClass,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UClass_ALightningEmitter_Statics::NewProp_EmitterSeed,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEmitter_Statics::PropPointers) < 2048);
UObject* (*const Z_Construct_UClass_ALightningEmitter_Statics::DependentSingletons[])() = {
	(UObject* (*)())Z_Construct_UClass_AActor,
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEmitter_Statics::DependentSingletons) < 16);
const UECodeGen_Private::FClassParams Z_Construct_UClass_ALightningEmitter_Statics::ClassParams = {
	&ALightningEmitter::StaticClass,
	"Engine",
	&StaticCppClassTypeInfo,
	DependentSingletons,
	FuncInfo,
	Z_Construct_UClass_ALightningEmitter_Statics::PropPointers,
	nullptr,
	UE_ARRAY_COUNT(DependentSingletons),
	UE_ARRAY_COUNT(FuncInfo),
	UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEmitter_Statics::PropPointers),
	0,
	0x009000A4u,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UClass_ALightningEmitter_Statics::Class_MetaDataParams), Z_Construct_UClass_ALightningEmitter_Statics::Class_MetaDataParams)
};
UClass* Z_Construct_UClass_ALightningEmitter()
{
	if (!Z_Registration_Info_UClass_ALightningEmitter.OuterSingleton)
	{
		UECodeGen_Private::ConstructUClass(Z_Registration_Info_UClass_ALightningEmitter.OuterSingleton, Z_Construct_UClass_ALightningEmitter_Statics::ClassParams);
	}
	return Z_Registration_Info_UClass_ALightningEmitter.OuterSingleton;
}
template<> LIGHTNINGS_API UClass* StaticClass<ALightningEmitter>()
{
	return ALightningEmitter::StaticClass();
}
void ALightningEmitter::ValidateGeneratedRepEnums(const TArray<struct FRepRecord>& ClassReps) const
{
	static const FName Name_bAutoActivate(TEXT("bAutoActivate"));
	static const FName Name_bLoop(TEXT("bLoop"));
	static const FName Name_LoopDuration(TEXT("LoopDuration"));
	static const FName Name_SourceAttachment(TEXT("SourceAttachment"));
	static const FName Name_TargetAttachment(TEXT("TargetAttachment"));
	static const FName Name_LightningParams(TEXT("LightningParams"));
	static const FName Name_BranchingParams(TEXT("BranchingParams"));
	static const FName Name_RootEmissionParams(TEXT("RootEmissionParams"));
	static const FName Name_BranchEmissionParams(TEXT("BranchEmissionParams"));
	static const FName Name_DisplacementMult(TEXT("DisplacementMult"));
	static const FName Name_TimeMultiplier(TEXT("TimeMultiplier"));
	static const FName Name_bUseSeparateThread(TEXT("bUseSeparateThread"));
	static const FName Name_bGenerateHitEvents(TEXT("bGenerateHitEvents"));
	static const FName Name_HitReaction(TEXT("HitReaction"));
	static const FName Name_bGenerateOverlapEvents(TEXT("bGenerateOverlapEvents"));
	static const FName Name_IgnoredActors(TEXT("IgnoredActors"));
	const bool bIsValid = true
		&& Name_bAutoActivate == ClassReps[(int32)ENetFields_Private::bAutoActivate].Property->GetFName()
		&& Name_bLoop == ClassReps[(int32)ENetFields_Private::bLoop].Property->GetFName()
		&& Name_LoopDuration == ClassReps[(int32)ENetFields_Private::LoopDuration].Property->GetFName()
		&& Name_SourceAttachment == ClassReps[(int32)ENetFields_Private::SourceAttachment].Property->GetFName()
		&& Name_TargetAttachment == ClassReps[(int32)ENetFields_Private::TargetAttachment].Property->GetFName()
		&& Name_LightningParams == ClassReps[(int32)ENetFields_Private::LightningParams].Property->GetFName()
		&& Name_BranchingParams == ClassReps[(int32)ENetFields_Private::BranchingParams].Property->GetFName()
		&& Name_RootEmissionParams == ClassReps[(int32)ENetFields_Private::RootEmissionParams].Property->GetFName()
		&& Name_BranchEmissionParams == ClassReps[(int32)ENetFields_Private::BranchEmissionParams].Property->GetFName()
		&& Name_DisplacementMult == ClassReps[(int32)ENetFields_Private::DisplacementMult].Property->GetFName()
		&& Name_TimeMultiplier == ClassReps[(int32)ENetFields_Private::TimeMultiplier].Property->GetFName()
		&& Name_bUseSeparateThread == ClassReps[(int32)ENetFields_Private::bUseSeparateThread].Property->GetFName()
		&& Name_bGenerateHitEvents == ClassReps[(int32)ENetFields_Private::bGenerateHitEvents].Property->GetFName()
		&& Name_HitReaction == ClassReps[(int32)ENetFields_Private::HitReaction].Property->GetFName()
		&& Name_bGenerateOverlapEvents == ClassReps[(int32)ENetFields_Private::bGenerateOverlapEvents].Property->GetFName()
		&& Name_IgnoredActors == ClassReps[(int32)ENetFields_Private::IgnoredActors].Property->GetFName();
	checkf(bIsValid, TEXT("UHT Generated Rep Indices do not match runtime populated Rep Indices for properties in ALightningEmitter"));
}
DEFINE_VTABLE_PTR_HELPER_CTOR(ALightningEmitter);
ALightningEmitter::~ALightningEmitter() {}
// End Class ALightningEmitter

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_Statics
{
	static constexpr FStructRegisterCompiledInInfo ScriptStructInfo[] = {
		{ FLightningSetupParams::StaticStruct, Z_Construct_UScriptStruct_FLightningSetupParams_Statics::NewStructOps, TEXT("LightningSetupParams"), &Z_Registration_Info_UScriptStruct_LightningSetupParams, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FLightningSetupParams), 3329481027U) },
	};
	static constexpr FClassRegisterCompiledInInfo ClassInfo[] = {
		{ Z_Construct_UClass_ALightningEmitter, ALightningEmitter::StaticClass, TEXT("ALightningEmitter"), &Z_Registration_Info_UClass_ALightningEmitter, CONSTRUCT_RELOAD_VERSION_INFO(FClassReloadVersionInfo, sizeof(ALightningEmitter), 2349568418U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_419437176(TEXT("/Script/Lightnings"),
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_Statics::ClassInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_Statics::ClassInfo),
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_Statics::ScriptStructInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEmitter_h_Statics::ScriptStructInfo),
	nullptr, 0);
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
