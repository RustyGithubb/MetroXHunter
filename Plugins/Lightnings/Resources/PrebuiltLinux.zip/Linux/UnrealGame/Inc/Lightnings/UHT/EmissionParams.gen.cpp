// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Parameters/EmissionParams.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeEmissionParams() {}

// Begin Cross Module References
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FEmissionParams();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin ScriptStruct FEmissionParams
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_EmissionParams;
class UScriptStruct* FEmissionParams::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_EmissionParams.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_EmissionParams.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FEmissionParams, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("EmissionParams"));
	}
	return Z_Registration_Info_UScriptStruct_EmissionParams.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FEmissionParams>()
{
	return FEmissionParams::StaticStruct();
}
struct Z_Construct_UScriptStruct_FEmissionParams_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "ModuleRelativePath", "Public/Parameters/EmissionParams.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bUseLightRenderer_MetaData[] = {
		{ "Category", "LightningEmission" },
		{ "ModuleRelativePath", "Public/Parameters/EmissionParams.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightMultiplier_MetaData[] = {
		{ "Category", "LightningEmission" },
		{ "ModuleRelativePath", "Public/Parameters/EmissionParams.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightExponent_MetaData[] = {
		{ "Category", "LightningEmission" },
		{ "ModuleRelativePath", "Public/Parameters/EmissionParams.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightRadius_MetaData[] = {
		{ "Category", "LightningEmission" },
		{ "ModuleRelativePath", "Public/Parameters/EmissionParams.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_LightVolumetricScattering_MetaData[] = {
		{ "Category", "LightningEmission" },
		{ "ModuleRelativePath", "Public/Parameters/EmissionParams.h" },
	};
#endif // WITH_METADATA
	static void NewProp_bUseLightRenderer_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bUseLightRenderer;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_LightMultiplier;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_LightExponent;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_LightRadius;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_LightVolumetricScattering;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FEmissionParams>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
void Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_bUseLightRenderer_SetBit(void* Obj)
{
	((FEmissionParams*)Obj)->bUseLightRenderer = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_bUseLightRenderer = { "bUseLightRenderer", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(FEmissionParams), &Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_bUseLightRenderer_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bUseLightRenderer_MetaData), NewProp_bUseLightRenderer_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightMultiplier = { "LightMultiplier", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FEmissionParams, LightMultiplier), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightMultiplier_MetaData), NewProp_LightMultiplier_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightExponent = { "LightExponent", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FEmissionParams, LightExponent), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightExponent_MetaData), NewProp_LightExponent_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightRadius = { "LightRadius", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FEmissionParams, LightRadius), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightRadius_MetaData), NewProp_LightRadius_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightVolumetricScattering = { "LightVolumetricScattering", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FEmissionParams, LightVolumetricScattering), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_LightVolumetricScattering_MetaData), NewProp_LightVolumetricScattering_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FEmissionParams_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_bUseLightRenderer,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightMultiplier,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightExponent,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightRadius,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FEmissionParams_Statics::NewProp_LightVolumetricScattering,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FEmissionParams_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FEmissionParams_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"EmissionParams",
	Z_Construct_UScriptStruct_FEmissionParams_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FEmissionParams_Statics::PropPointers),
	sizeof(FEmissionParams),
	alignof(FEmissionParams),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FEmissionParams_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FEmissionParams_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FEmissionParams()
{
	if (!Z_Registration_Info_UScriptStruct_EmissionParams.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_EmissionParams.InnerSingleton, Z_Construct_UScriptStruct_FEmissionParams_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_EmissionParams.InnerSingleton;
}
// End ScriptStruct FEmissionParams

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_EmissionParams_h_Statics
{
	static constexpr FStructRegisterCompiledInInfo ScriptStructInfo[] = {
		{ FEmissionParams::StaticStruct, Z_Construct_UScriptStruct_FEmissionParams_Statics::NewStructOps, TEXT("EmissionParams"), &Z_Registration_Info_UScriptStruct_EmissionParams, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FEmissionParams), 1216152273U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_EmissionParams_h_20484866(TEXT("/Script/Lightnings"),
	nullptr, 0,
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_EmissionParams_h_Statics::ScriptStructInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_EmissionParams_h_Statics::ScriptStructInfo),
	nullptr, 0);
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
