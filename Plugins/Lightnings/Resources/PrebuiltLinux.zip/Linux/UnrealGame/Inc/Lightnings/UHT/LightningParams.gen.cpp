// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Parameters/LightningParams.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeLightningParams() {}

// Begin Cross Module References
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FFloatRange();
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FLinearColor();
ENGINE_API UClass* Z_Construct_UClass_UCurveFloat_NoRegister();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningParams();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin ScriptStruct FLightningParams
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_LightningParams;
class UScriptStruct* FLightningParams::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_LightningParams.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_LightningParams.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FLightningParams, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("LightningParams"));
	}
	return Z_Registration_Info_UScriptStruct_LightningParams.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FLightningParams>()
{
	return FLightningParams::StaticStruct();
}
struct Z_Construct_UScriptStruct_FLightningParams_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Color_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Color of particles\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Color of particles" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_RootParticlesWidth_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Width form of root lightnings\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Width form of root lightnings" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BranchParticlesWidth_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Width form of branches\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Width form of branches" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_ParticlesWidthScale_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Width scale of particles\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Width scale of particles" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_bInstant_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Whether lightnings are spawned instantly\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Whether lightnings are spawned instantly" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkVelocityRange_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Linear speed of spark in cm/s\n" },
		{ "EditCondition", "bInstant == false" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Linear speed of spark in cm/s" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkVelocityFading_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Fading of spark velocity with order of lightning\n" },
		{ "EditCondition", "bInstant == false" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Fading of spark velocity with order of lightning" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkDelayRange_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Duration of delays in spark movement (in seconds)\n" },
		{ "EditCondition", "bInstant == false" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Duration of delays in spark movement (in seconds)" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_NoiseMult_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Noise multiplier\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Noise multiplier" },
		{ "UIMax", "2.0" },
		{ "UIMin", "0.0" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkStep_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// LengthRange of steps in spark movement (in cm)\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "LengthRange of steps in spark movement (in cm)" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_FlashingCurve_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Root flashing curve\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Root flashing curve" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_FlashingRate_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Root flashing rate\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Root flashing rate" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_FlashingForce_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Root flashing force\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Root flashing force" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkIntensity_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Spark light intensity\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Spark light intensity" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_TrailIntensity_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Spark trail light intensity\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Spark trail light intensity" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_TrailIntensityFading_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Fading of spark trail light intensity with order of lightning\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Fading of spark trail light intensity with order of lightning" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_BoltIntensity_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "// Root light intensity\n" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Root light intensity" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkFadeOutSpeedMult_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "/**\n\x09* Multiplier of speed of lightning spark fade out\n\x09* Value of 1. means it will fade with speed of root flashing\n\x09*/" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Multiplier of speed of lightning spark fade out\nValue of 1. means it will fade with speed of root flashing" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_TrailFadeOutSpeedMult_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "/**\n\x09* Multiplier of speed of lightning trail fade out\n\x09* Value of 1. means it will fade with speed of root flashing\n\x09*/" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Multiplier of speed of lightning trail fade out\nValue of 1. means it will fade with speed of root flashing" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_NumSegments_MetaData[] = {
		{ "Category", "Variables" },
		{ "Comment", "/**\n\x09* Lightning segmentation level\n\x09* Higher values make lightning be more noizy\n\x09*/" },
		{ "ModuleRelativePath", "Public/Parameters/LightningParams.h" },
		{ "ToolTip", "Lightning segmentation level\nHigher values make lightning be more noizy" },
		{ "UIMin", "2" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Color;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_RootParticlesWidth;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_BranchParticlesWidth;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_ParticlesWidthScale;
	static void NewProp_bInstant_SetBit(void* Obj);
	static const UECodeGen_Private::FBoolPropertyParams NewProp_bInstant;
	static const UECodeGen_Private::FStructPropertyParams NewProp_SparkVelocityRange;
	static const UECodeGen_Private::FStructPropertyParams NewProp_SparkVelocityFading;
	static const UECodeGen_Private::FStructPropertyParams NewProp_SparkDelayRange;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_NoiseMult;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_SparkStep;
	static const UECodeGen_Private::FObjectPropertyParams NewProp_FlashingCurve;
	static const UECodeGen_Private::FStructPropertyParams NewProp_FlashingRate;
	static const UECodeGen_Private::FStructPropertyParams NewProp_FlashingForce;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_SparkIntensity;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_TrailIntensity;
	static const UECodeGen_Private::FStructPropertyParams NewProp_TrailIntensityFading;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_BoltIntensity;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_SparkFadeOutSpeedMult;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_TrailFadeOutSpeedMult;
	static const UECodeGen_Private::FIntPropertyParams NewProp_NumSegments;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FLightningParams>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_Color = { "Color", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, Color), Z_Construct_UScriptStruct_FLinearColor, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Color_MetaData), NewProp_Color_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_RootParticlesWidth = { "RootParticlesWidth", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, RootParticlesWidth), Z_Construct_UClass_UCurveFloat_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_RootParticlesWidth_MetaData), NewProp_RootParticlesWidth_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_BranchParticlesWidth = { "BranchParticlesWidth", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, BranchParticlesWidth), Z_Construct_UClass_UCurveFloat_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BranchParticlesWidth_MetaData), NewProp_BranchParticlesWidth_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_ParticlesWidthScale = { "ParticlesWidthScale", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, ParticlesWidthScale), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_ParticlesWidthScale_MetaData), NewProp_ParticlesWidthScale_MetaData) };
void Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_bInstant_SetBit(void* Obj)
{
	((FLightningParams*)Obj)->bInstant = 1;
}
const UECodeGen_Private::FBoolPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_bInstant = { "bInstant", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Bool | UECodeGen_Private::EPropertyGenFlags::NativeBool, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, sizeof(bool), sizeof(FLightningParams), &Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_bInstant_SetBit, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_bInstant_MetaData), NewProp_bInstant_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkVelocityRange = { "SparkVelocityRange", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, SparkVelocityRange), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkVelocityRange_MetaData), NewProp_SparkVelocityRange_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkVelocityFading = { "SparkVelocityFading", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, SparkVelocityFading), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkVelocityFading_MetaData), NewProp_SparkVelocityFading_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkDelayRange = { "SparkDelayRange", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, SparkDelayRange), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkDelayRange_MetaData), NewProp_SparkDelayRange_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_NoiseMult = { "NoiseMult", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, NoiseMult), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_NoiseMult_MetaData), NewProp_NoiseMult_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkStep = { "SparkStep", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, SparkStep), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkStep_MetaData), NewProp_SparkStep_MetaData) };
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_FlashingCurve = { "FlashingCurve", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, FlashingCurve), Z_Construct_UClass_UCurveFloat_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_FlashingCurve_MetaData), NewProp_FlashingCurve_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_FlashingRate = { "FlashingRate", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, FlashingRate), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_FlashingRate_MetaData), NewProp_FlashingRate_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_FlashingForce = { "FlashingForce", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, FlashingForce), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_FlashingForce_MetaData), NewProp_FlashingForce_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkIntensity = { "SparkIntensity", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, SparkIntensity), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkIntensity_MetaData), NewProp_SparkIntensity_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_TrailIntensity = { "TrailIntensity", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, TrailIntensity), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_TrailIntensity_MetaData), NewProp_TrailIntensity_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_TrailIntensityFading = { "TrailIntensityFading", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, TrailIntensityFading), Z_Construct_UScriptStruct_FFloatRange, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_TrailIntensityFading_MetaData), NewProp_TrailIntensityFading_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_BoltIntensity = { "BoltIntensity", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, BoltIntensity), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_BoltIntensity_MetaData), NewProp_BoltIntensity_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkFadeOutSpeedMult = { "SparkFadeOutSpeedMult", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, SparkFadeOutSpeedMult), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkFadeOutSpeedMult_MetaData), NewProp_SparkFadeOutSpeedMult_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_TrailFadeOutSpeedMult = { "TrailFadeOutSpeedMult", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, TrailFadeOutSpeedMult), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_TrailFadeOutSpeedMult_MetaData), NewProp_TrailFadeOutSpeedMult_MetaData) };
const UECodeGen_Private::FIntPropertyParams Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_NumSegments = { "NumSegments", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningParams, NumSegments), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_NumSegments_MetaData), NewProp_NumSegments_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FLightningParams_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_Color,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_RootParticlesWidth,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_BranchParticlesWidth,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_ParticlesWidthScale,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_bInstant,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkVelocityRange,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkVelocityFading,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkDelayRange,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_NoiseMult,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkStep,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_FlashingCurve,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_FlashingRate,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_FlashingForce,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkIntensity,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_TrailIntensity,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_TrailIntensityFading,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_BoltIntensity,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_SparkFadeOutSpeedMult,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_TrailFadeOutSpeedMult,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningParams_Statics::NewProp_NumSegments,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningParams_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FLightningParams_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"LightningParams",
	Z_Construct_UScriptStruct_FLightningParams_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningParams_Statics::PropPointers),
	sizeof(FLightningParams),
	alignof(FLightningParams),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningParams_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FLightningParams_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FLightningParams()
{
	if (!Z_Registration_Info_UScriptStruct_LightningParams.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_LightningParams.InnerSingleton, Z_Construct_UScriptStruct_FLightningParams_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_LightningParams.InnerSingleton;
}
// End ScriptStruct FLightningParams

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningParams_h_Statics
{
	static constexpr FStructRegisterCompiledInInfo ScriptStructInfo[] = {
		{ FLightningParams::StaticStruct, Z_Construct_UScriptStruct_FLightningParams_Statics::NewStructOps, TEXT("LightningParams"), &Z_Registration_Info_UScriptStruct_LightningParams, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FLightningParams), 2783240090U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningParams_h_2303325317(TEXT("/Script/Lightnings"),
	nullptr, 0,
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningParams_h_Statics::ScriptStructInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningParams_h_Statics::ScriptStructInfo),
	nullptr, 0);
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
