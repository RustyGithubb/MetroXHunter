// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Framework/LightningAttachment.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeLightningAttachment() {}

// Begin Cross Module References
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FVector();
ENGINE_API UClass* Z_Construct_UClass_AActor_NoRegister();
LIGHTNINGS_API UEnum* Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace();
LIGHTNINGS_API UEnum* Z_Construct_UEnum_Lightnings_EAttachType();
LIGHTNINGS_API UEnum* Z_Construct_UEnum_Lightnings_EAttachVolumeType();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FActorAttachParams();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FAttachVolumeBox();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FAttachVolumeCylinder();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FAttachVolumeSphere();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningAttachment();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin Enum EAttachType
static FEnumRegistrationInfo Z_Registration_Info_UEnum_EAttachType;
static UEnum* EAttachType_StaticEnum()
{
	if (!Z_Registration_Info_UEnum_EAttachType.OuterSingleton)
	{
		Z_Registration_Info_UEnum_EAttachType.OuterSingleton = GetStaticEnum(Z_Construct_UEnum_Lightnings_EAttachType, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("EAttachType"));
	}
	return Z_Registration_Info_UEnum_EAttachType.OuterSingleton;
}
template<> LIGHTNINGS_API UEnum* StaticEnum<EAttachType>()
{
	return EAttachType_StaticEnum();
}
struct Z_Construct_UEnum_Lightnings_EAttachType_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Enum_MetaDataParams[] = {
		{ "AT_Actor.Comment", "// Attach to specific actor location (or it's component location)\n" },
		{ "AT_Actor.DisplayName", "Actor" },
		{ "AT_Actor.Name", "EAttachType::AT_Actor" },
		{ "AT_Actor.ToolTip", "Attach to specific actor location (or it's component location)" },
		{ "AT_Location.Comment", "// Attach to specific location\n" },
		{ "AT_Location.DisplayName", "Location" },
		{ "AT_Location.Name", "EAttachType::AT_Location" },
		{ "AT_Location.ToolTip", "Attach to specific location" },
		{ "AT_Self.Comment", "// Attach to emitter location\n" },
		{ "AT_Self.DisplayName", "Self" },
		{ "AT_Self.Name", "EAttachType::AT_Self" },
		{ "AT_Self.ToolTip", "Attach to emitter location" },
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* Describes a type of the lightning attachment\n*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "Describes a type of the lightning attachment" },
	};
#endif // WITH_METADATA
	static constexpr UECodeGen_Private::FEnumeratorParam Enumerators[] = {
		{ "EAttachType::AT_Self", (int64)EAttachType::AT_Self },
		{ "EAttachType::AT_Location", (int64)EAttachType::AT_Location },
		{ "EAttachType::AT_Actor", (int64)EAttachType::AT_Actor },
	};
	static const UECodeGen_Private::FEnumParams EnumParams;
};
const UECodeGen_Private::FEnumParams Z_Construct_UEnum_Lightnings_EAttachType_Statics::EnumParams = {
	(UObject*(*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	"EAttachType",
	"EAttachType",
	Z_Construct_UEnum_Lightnings_EAttachType_Statics::Enumerators,
	RF_Public|RF_Transient|RF_MarkAsNative,
	UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EAttachType_Statics::Enumerators),
	EEnumFlags::None,
	(uint8)UEnum::ECppForm::EnumClass,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EAttachType_Statics::Enum_MetaDataParams), Z_Construct_UEnum_Lightnings_EAttachType_Statics::Enum_MetaDataParams)
};
UEnum* Z_Construct_UEnum_Lightnings_EAttachType()
{
	if (!Z_Registration_Info_UEnum_EAttachType.InnerSingleton)
	{
		UECodeGen_Private::ConstructUEnum(Z_Registration_Info_UEnum_EAttachType.InnerSingleton, Z_Construct_UEnum_Lightnings_EAttachType_Statics::EnumParams);
	}
	return Z_Registration_Info_UEnum_EAttachType.InnerSingleton;
}
// End Enum EAttachType

// Begin Enum EAttachVolumeType
static FEnumRegistrationInfo Z_Registration_Info_UEnum_EAttachVolumeType;
static UEnum* EAttachVolumeType_StaticEnum()
{
	if (!Z_Registration_Info_UEnum_EAttachVolumeType.OuterSingleton)
	{
		Z_Registration_Info_UEnum_EAttachVolumeType.OuterSingleton = GetStaticEnum(Z_Construct_UEnum_Lightnings_EAttachVolumeType, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("EAttachVolumeType"));
	}
	return Z_Registration_Info_UEnum_EAttachVolumeType.OuterSingleton;
}
template<> LIGHTNINGS_API UEnum* StaticEnum<EAttachVolumeType>()
{
	return EAttachVolumeType_StaticEnum();
}
struct Z_Construct_UEnum_Lightnings_EAttachVolumeType_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Enum_MetaDataParams[] = {
		{ "AV_Box.Comment", "// Box-type, is specified by extent-vector\n" },
		{ "AV_Box.DisplayName", "Box" },
		{ "AV_Box.Name", "EAttachVolumeType::AV_Box" },
		{ "AV_Box.ToolTip", "Box-type, is specified by extent-vector" },
		{ "AV_Cylinder.Comment", "// Cylinder-type, is specified by axis vector, height and radius\n" },
		{ "AV_Cylinder.DisplayName", "Cylinder" },
		{ "AV_Cylinder.Name", "EAttachVolumeType::AV_Cylinder" },
		{ "AV_Cylinder.ToolTip", "Cylinder-type, is specified by axis vector, height and radius" },
		{ "AV_Point.Comment", "// Don't use randomization (point-type)\n" },
		{ "AV_Point.DisplayName", "Point" },
		{ "AV_Point.Name", "EAttachVolumeType::AV_Point" },
		{ "AV_Point.ToolTip", "Don't use randomization (point-type)" },
		{ "AV_Sphere.Comment", "// Sphere-type, is specified by radius\n" },
		{ "AV_Sphere.DisplayName", "Sphere" },
		{ "AV_Sphere.Name", "EAttachVolumeType::AV_Sphere" },
		{ "AV_Sphere.ToolTip", "Sphere-type, is specified by radius" },
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* Describes a type of the attachment's randomization volume\n*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "Describes a type of the attachment's randomization volume" },
	};
#endif // WITH_METADATA
	static constexpr UECodeGen_Private::FEnumeratorParam Enumerators[] = {
		{ "EAttachVolumeType::AV_Point", (int64)EAttachVolumeType::AV_Point },
		{ "EAttachVolumeType::AV_Box", (int64)EAttachVolumeType::AV_Box },
		{ "EAttachVolumeType::AV_Cylinder", (int64)EAttachVolumeType::AV_Cylinder },
		{ "EAttachVolumeType::AV_Sphere", (int64)EAttachVolumeType::AV_Sphere },
	};
	static const UECodeGen_Private::FEnumParams EnumParams;
};
const UECodeGen_Private::FEnumParams Z_Construct_UEnum_Lightnings_EAttachVolumeType_Statics::EnumParams = {
	(UObject*(*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	"EAttachVolumeType",
	"EAttachVolumeType",
	Z_Construct_UEnum_Lightnings_EAttachVolumeType_Statics::Enumerators,
	RF_Public|RF_Transient|RF_MarkAsNative,
	UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EAttachVolumeType_Statics::Enumerators),
	EEnumFlags::None,
	(uint8)UEnum::ECppForm::EnumClass,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EAttachVolumeType_Statics::Enum_MetaDataParams), Z_Construct_UEnum_Lightnings_EAttachVolumeType_Statics::Enum_MetaDataParams)
};
UEnum* Z_Construct_UEnum_Lightnings_EAttachVolumeType()
{
	if (!Z_Registration_Info_UEnum_EAttachVolumeType.InnerSingleton)
	{
		UECodeGen_Private::ConstructUEnum(Z_Registration_Info_UEnum_EAttachVolumeType.InnerSingleton, Z_Construct_UEnum_Lightnings_EAttachVolumeType_Statics::EnumParams);
	}
	return Z_Registration_Info_UEnum_EAttachVolumeType.InnerSingleton;
}
// End Enum EAttachVolumeType

// Begin Enum EAttachActorDirectionSpace
static FEnumRegistrationInfo Z_Registration_Info_UEnum_EAttachActorDirectionSpace;
static UEnum* EAttachActorDirectionSpace_StaticEnum()
{
	if (!Z_Registration_Info_UEnum_EAttachActorDirectionSpace.OuterSingleton)
	{
		Z_Registration_Info_UEnum_EAttachActorDirectionSpace.OuterSingleton = GetStaticEnum(Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("EAttachActorDirectionSpace"));
	}
	return Z_Registration_Info_UEnum_EAttachActorDirectionSpace.OuterSingleton;
}
template<> LIGHTNINGS_API UEnum* StaticEnum<EAttachActorDirectionSpace>()
{
	return EAttachActorDirectionSpace_StaticEnum();
}
struct Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Enum_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* In which space the lightning direction should be calculated when is attached to actor\n*/" },
		{ "DS_Actor.DisplayName", "Actor" },
		{ "DS_Actor.Name", "EAttachActorDirectionSpace::DS_Actor" },
		{ "DS_Component.DisplayName", "Component" },
		{ "DS_Component.Name", "EAttachActorDirectionSpace::DS_Component" },
		{ "DS_Socket.DisplayName", "Socket" },
		{ "DS_Socket.Name", "EAttachActorDirectionSpace::DS_Socket" },
		{ "DS_World.DisplayName", "World" },
		{ "DS_World.Name", "EAttachActorDirectionSpace::DS_World" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "In which space the lightning direction should be calculated when is attached to actor" },
	};
#endif // WITH_METADATA
	static constexpr UECodeGen_Private::FEnumeratorParam Enumerators[] = {
		{ "EAttachActorDirectionSpace::DS_World", (int64)EAttachActorDirectionSpace::DS_World },
		{ "EAttachActorDirectionSpace::DS_Actor", (int64)EAttachActorDirectionSpace::DS_Actor },
		{ "EAttachActorDirectionSpace::DS_Component", (int64)EAttachActorDirectionSpace::DS_Component },
		{ "EAttachActorDirectionSpace::DS_Socket", (int64)EAttachActorDirectionSpace::DS_Socket },
	};
	static const UECodeGen_Private::FEnumParams EnumParams;
};
const UECodeGen_Private::FEnumParams Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace_Statics::EnumParams = {
	(UObject*(*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	"EAttachActorDirectionSpace",
	"EAttachActorDirectionSpace",
	Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace_Statics::Enumerators,
	RF_Public|RF_Transient|RF_MarkAsNative,
	UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace_Statics::Enumerators),
	EEnumFlags::None,
	(uint8)UEnum::ECppForm::EnumClass,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace_Statics::Enum_MetaDataParams), Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace_Statics::Enum_MetaDataParams)
};
UEnum* Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace()
{
	if (!Z_Registration_Info_UEnum_EAttachActorDirectionSpace.InnerSingleton)
	{
		UECodeGen_Private::ConstructUEnum(Z_Registration_Info_UEnum_EAttachActorDirectionSpace.InnerSingleton, Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace_Statics::EnumParams);
	}
	return Z_Registration_Info_UEnum_EAttachActorDirectionSpace.InnerSingleton;
}
// End Enum EAttachActorDirectionSpace

// Begin ScriptStruct FAttachVolumeBox
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_AttachVolumeBox;
class UScriptStruct* FAttachVolumeBox::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_AttachVolumeBox.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_AttachVolumeBox.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FAttachVolumeBox, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("AttachVolumeBox"));
	}
	return Z_Registration_Info_UScriptStruct_AttachVolumeBox.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FAttachVolumeBox>()
{
	return FAttachVolumeBox::StaticStruct();
}
struct Z_Construct_UScriptStruct_FAttachVolumeBox_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* Specific structs for attachment volumes\n*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "Specific structs for attachment volumes" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Size_MetaData[] = {
		{ "Category", "BoxAttachVolume" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Size;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FAttachVolumeBox>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::NewProp_Size = { "Size", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FAttachVolumeBox, Size), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Size_MetaData), NewProp_Size_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::NewProp_Size,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"AttachVolumeBox",
	Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::PropPointers),
	sizeof(FAttachVolumeBox),
	alignof(FAttachVolumeBox),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FAttachVolumeBox()
{
	if (!Z_Registration_Info_UScriptStruct_AttachVolumeBox.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_AttachVolumeBox.InnerSingleton, Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_AttachVolumeBox.InnerSingleton;
}
// End ScriptStruct FAttachVolumeBox

// Begin ScriptStruct FAttachVolumeCylinder
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_AttachVolumeCylinder;
class UScriptStruct* FAttachVolumeCylinder::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_AttachVolumeCylinder.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_AttachVolumeCylinder.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FAttachVolumeCylinder, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("AttachVolumeCylinder"));
	}
	return Z_Registration_Info_UScriptStruct_AttachVolumeCylinder.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FAttachVolumeCylinder>()
{
	return FAttachVolumeCylinder::StaticStruct();
}
struct Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Axis_MetaData[] = {
		{ "Category", "CylinderAttachVolume" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Height_MetaData[] = {
		{ "Category", "CylinderAttachVolume" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Radius_MetaData[] = {
		{ "Category", "CylinderAttachVolume" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Axis;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Height;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Radius;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FAttachVolumeCylinder>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::NewProp_Axis = { "Axis", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FAttachVolumeCylinder, Axis), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Axis_MetaData), NewProp_Axis_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::NewProp_Height = { "Height", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FAttachVolumeCylinder, Height), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Height_MetaData), NewProp_Height_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::NewProp_Radius = { "Radius", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FAttachVolumeCylinder, Radius), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Radius_MetaData), NewProp_Radius_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::NewProp_Axis,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::NewProp_Height,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::NewProp_Radius,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"AttachVolumeCylinder",
	Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::PropPointers),
	sizeof(FAttachVolumeCylinder),
	alignof(FAttachVolumeCylinder),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FAttachVolumeCylinder()
{
	if (!Z_Registration_Info_UScriptStruct_AttachVolumeCylinder.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_AttachVolumeCylinder.InnerSingleton, Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_AttachVolumeCylinder.InnerSingleton;
}
// End ScriptStruct FAttachVolumeCylinder

// Begin ScriptStruct FAttachVolumeSphere
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_AttachVolumeSphere;
class UScriptStruct* FAttachVolumeSphere::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_AttachVolumeSphere.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_AttachVolumeSphere.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FAttachVolumeSphere, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("AttachVolumeSphere"));
	}
	return Z_Registration_Info_UScriptStruct_AttachVolumeSphere.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FAttachVolumeSphere>()
{
	return FAttachVolumeSphere::StaticStruct();
}
struct Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Radius_MetaData[] = {
		{ "Category", "SphereAttachVolume" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Radius;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FAttachVolumeSphere>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::NewProp_Radius = { "Radius", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FAttachVolumeSphere, Radius), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Radius_MetaData), NewProp_Radius_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::NewProp_Radius,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"AttachVolumeSphere",
	Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::PropPointers),
	sizeof(FAttachVolumeSphere),
	alignof(FAttachVolumeSphere),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FAttachVolumeSphere()
{
	if (!Z_Registration_Info_UScriptStruct_AttachVolumeSphere.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_AttachVolumeSphere.InnerSingleton, Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_AttachVolumeSphere.InnerSingleton;
}
// End ScriptStruct FAttachVolumeSphere

// Begin ScriptStruct FActorAttachParams
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_ActorAttachParams;
class UScriptStruct* FActorAttachParams::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_ActorAttachParams.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_ActorAttachParams.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FActorAttachParams, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("ActorAttachParams"));
	}
	return Z_Registration_Info_UScriptStruct_ActorAttachParams.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FActorAttachParams>()
{
	return FActorAttachParams::StaticStruct();
}
struct Z_Construct_UScriptStruct_FActorAttachParams_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* Contains information about the actor to which the lightning is attached\n*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "Contains information about the actor to which the lightning is attached" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Actor_MetaData[] = {
		{ "Category", "ActorAttachParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_ComponentName_MetaData[] = {
		{ "Category", "ActorAttachParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SocketName_MetaData[] = {
		{ "Category", "ActorAttachParams" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_DirectionSpace_MetaData[] = {
		{ "Category", "ActorAttachParams" },
		{ "Comment", "// In which space the lightning direction should be calculated\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "In which space the lightning direction should be calculated" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FObjectPropertyParams NewProp_Actor;
	static const UECodeGen_Private::FNamePropertyParams NewProp_ComponentName;
	static const UECodeGen_Private::FNamePropertyParams NewProp_SocketName;
	static const UECodeGen_Private::FBytePropertyParams NewProp_DirectionSpace_Underlying;
	static const UECodeGen_Private::FEnumPropertyParams NewProp_DirectionSpace;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FActorAttachParams>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FObjectPropertyParams Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_Actor = { "Actor", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Object, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FActorAttachParams, Actor), Z_Construct_UClass_AActor_NoRegister, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Actor_MetaData), NewProp_Actor_MetaData) };
const UECodeGen_Private::FNamePropertyParams Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_ComponentName = { "ComponentName", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Name, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FActorAttachParams, ComponentName), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_ComponentName_MetaData), NewProp_ComponentName_MetaData) };
const UECodeGen_Private::FNamePropertyParams Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_SocketName = { "SocketName", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Name, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FActorAttachParams, SocketName), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SocketName_MetaData), NewProp_SocketName_MetaData) };
const UECodeGen_Private::FBytePropertyParams Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_DirectionSpace_Underlying = { "UnderlyingType", nullptr, (EPropertyFlags)0x0000000000000000, UECodeGen_Private::EPropertyGenFlags::Byte, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, nullptr, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FEnumPropertyParams Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_DirectionSpace = { "DirectionSpace", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Enum, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FActorAttachParams, DirectionSpace), Z_Construct_UEnum_Lightnings_EAttachActorDirectionSpace, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_DirectionSpace_MetaData), NewProp_DirectionSpace_MetaData) }; // 840050906
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FActorAttachParams_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_Actor,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_ComponentName,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_SocketName,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_DirectionSpace_Underlying,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewProp_DirectionSpace,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FActorAttachParams_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FActorAttachParams_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"ActorAttachParams",
	Z_Construct_UScriptStruct_FActorAttachParams_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FActorAttachParams_Statics::PropPointers),
	sizeof(FActorAttachParams),
	alignof(FActorAttachParams),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FActorAttachParams_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FActorAttachParams_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FActorAttachParams()
{
	if (!Z_Registration_Info_UScriptStruct_ActorAttachParams.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_ActorAttachParams.InnerSingleton, Z_Construct_UScriptStruct_FActorAttachParams_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_ActorAttachParams.InnerSingleton;
}
// End ScriptStruct FActorAttachParams

// Begin ScriptStruct FLightningAttachment
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_LightningAttachment;
class UScriptStruct* FLightningAttachment::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_LightningAttachment.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_LightningAttachment.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FLightningAttachment, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("LightningAttachment"));
	}
	return Z_Registration_Info_UScriptStruct_LightningAttachment.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FLightningAttachment>()
{
	return FLightningAttachment::StaticStruct();
}
struct Z_Construct_UScriptStruct_FLightningAttachment_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* Contains information about attachment of\n* the lightning to a specific point in the world.\n* \n* A lightning can be attached to emitter's location,\n* some specific location or some actor's component\n* (to it's root component if component name is not specified).\n* \n* An attachment point can be adjusted by random offset in\n* a specific volume described by AttachVolumeType and AttachVolume.\n*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "Contains information about attachment of\nthe lightning to a specific point in the world.\n\nA lightning can be attached to emitter's location,\nsome specific location or some actor's component\n(to it's root component if component name is not specified).\n\nAn attachment point can be adjusted by random offset in\na specific volume described by AttachVolumeType and AttachVolume." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Type_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Location_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "EditCondition", "Type == EAttachType::AT_Location" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_ActorAttachParams_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "EditCondition", "Type == EAttachType::AT_Actor" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Direction_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "Comment", "/**\n\x09* Velocity direction of the lightning in that point.\n\x09* Use GetLightningDirection() to get exact direction, converted from desired space.\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
		{ "ToolTip", "Velocity direction of the lightning in that point.\nUse GetLightningDirection() to get exact direction, converted from desired space." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_AttachVolumeType_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_AttachVolumeBox_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "EditCondition", "AttachVolumeType == EAttachVolumeType::AV_Box" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_AttachVolumeCylinder_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "EditCondition", "AttachVolumeType == EAttachVolumeType::AV_Cylinder" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_AttachVolumeSphere_MetaData[] = {
		{ "Category", "LightningAttachment" },
		{ "EditCondition", "AttachVolumeType == EAttachVolumeType::AV_Sphere" },
		{ "ModuleRelativePath", "Public/Framework/LightningAttachment.h" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FBytePropertyParams NewProp_Type_Underlying;
	static const UECodeGen_Private::FEnumPropertyParams NewProp_Type;
	static const UECodeGen_Private::FStructPropertyParams NewProp_Location;
	static const UECodeGen_Private::FStructPropertyParams NewProp_ActorAttachParams;
	static const UECodeGen_Private::FStructPropertyParams NewProp_Direction;
	static const UECodeGen_Private::FBytePropertyParams NewProp_AttachVolumeType_Underlying;
	static const UECodeGen_Private::FEnumPropertyParams NewProp_AttachVolumeType;
	static const UECodeGen_Private::FStructPropertyParams NewProp_AttachVolumeBox;
	static const UECodeGen_Private::FStructPropertyParams NewProp_AttachVolumeCylinder;
	static const UECodeGen_Private::FStructPropertyParams NewProp_AttachVolumeSphere;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FLightningAttachment>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FBytePropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Type_Underlying = { "UnderlyingType", nullptr, (EPropertyFlags)0x0000000000000000, UECodeGen_Private::EPropertyGenFlags::Byte, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, nullptr, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FEnumPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Type = { "Type", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Enum, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, Type), Z_Construct_UEnum_Lightnings_EAttachType, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Type_MetaData), NewProp_Type_MetaData) }; // 391596536
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Location = { "Location", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, Location), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Location_MetaData), NewProp_Location_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_ActorAttachParams = { "ActorAttachParams", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, ActorAttachParams), Z_Construct_UScriptStruct_FActorAttachParams, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_ActorAttachParams_MetaData), NewProp_ActorAttachParams_MetaData) }; // 897370825
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Direction = { "Direction", nullptr, (EPropertyFlags)0x0010000200000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, Direction), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Direction_MetaData), NewProp_Direction_MetaData) };
const UECodeGen_Private::FBytePropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeType_Underlying = { "UnderlyingType", nullptr, (EPropertyFlags)0x0000000000000000, UECodeGen_Private::EPropertyGenFlags::Byte, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, nullptr, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FEnumPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeType = { "AttachVolumeType", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Enum, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, AttachVolumeType), Z_Construct_UEnum_Lightnings_EAttachVolumeType, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_AttachVolumeType_MetaData), NewProp_AttachVolumeType_MetaData) }; // 2745269856
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeBox = { "AttachVolumeBox", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, AttachVolumeBox), Z_Construct_UScriptStruct_FAttachVolumeBox, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_AttachVolumeBox_MetaData), NewProp_AttachVolumeBox_MetaData) }; // 3406661359
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeCylinder = { "AttachVolumeCylinder", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, AttachVolumeCylinder), Z_Construct_UScriptStruct_FAttachVolumeCylinder, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_AttachVolumeCylinder_MetaData), NewProp_AttachVolumeCylinder_MetaData) }; // 1693523559
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeSphere = { "AttachVolumeSphere", nullptr, (EPropertyFlags)0x0010000000000005, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningAttachment, AttachVolumeSphere), Z_Construct_UScriptStruct_FAttachVolumeSphere, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_AttachVolumeSphere_MetaData), NewProp_AttachVolumeSphere_MetaData) }; // 1910460600
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FLightningAttachment_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Type_Underlying,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Type,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Location,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_ActorAttachParams,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_Direction,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeType_Underlying,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeType,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeBox,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeCylinder,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewProp_AttachVolumeSphere,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningAttachment_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FLightningAttachment_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"LightningAttachment",
	Z_Construct_UScriptStruct_FLightningAttachment_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningAttachment_Statics::PropPointers),
	sizeof(FLightningAttachment),
	alignof(FLightningAttachment),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningAttachment_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FLightningAttachment_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FLightningAttachment()
{
	if (!Z_Registration_Info_UScriptStruct_LightningAttachment.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_LightningAttachment.InnerSingleton, Z_Construct_UScriptStruct_FLightningAttachment_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_LightningAttachment.InnerSingleton;
}
// End ScriptStruct FLightningAttachment

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_Statics
{
	static constexpr FEnumRegisterCompiledInInfo EnumInfo[] = {
		{ EAttachType_StaticEnum, TEXT("EAttachType"), &Z_Registration_Info_UEnum_EAttachType, CONSTRUCT_RELOAD_VERSION_INFO(FEnumReloadVersionInfo, 391596536U) },
		{ EAttachVolumeType_StaticEnum, TEXT("EAttachVolumeType"), &Z_Registration_Info_UEnum_EAttachVolumeType, CONSTRUCT_RELOAD_VERSION_INFO(FEnumReloadVersionInfo, 2745269856U) },
		{ EAttachActorDirectionSpace_StaticEnum, TEXT("EAttachActorDirectionSpace"), &Z_Registration_Info_UEnum_EAttachActorDirectionSpace, CONSTRUCT_RELOAD_VERSION_INFO(FEnumReloadVersionInfo, 840050906U) },
	};
	static constexpr FStructRegisterCompiledInInfo ScriptStructInfo[] = {
		{ FAttachVolumeBox::StaticStruct, Z_Construct_UScriptStruct_FAttachVolumeBox_Statics::NewStructOps, TEXT("AttachVolumeBox"), &Z_Registration_Info_UScriptStruct_AttachVolumeBox, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FAttachVolumeBox), 3406661359U) },
		{ FAttachVolumeCylinder::StaticStruct, Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics::NewStructOps, TEXT("AttachVolumeCylinder"), &Z_Registration_Info_UScriptStruct_AttachVolumeCylinder, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FAttachVolumeCylinder), 1693523559U) },
		{ FAttachVolumeSphere::StaticStruct, Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics::NewStructOps, TEXT("AttachVolumeSphere"), &Z_Registration_Info_UScriptStruct_AttachVolumeSphere, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FAttachVolumeSphere), 1910460600U) },
		{ FActorAttachParams::StaticStruct, Z_Construct_UScriptStruct_FActorAttachParams_Statics::NewStructOps, TEXT("ActorAttachParams"), &Z_Registration_Info_UScriptStruct_ActorAttachParams, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FActorAttachParams), 897370825U) },
		{ FLightningAttachment::StaticStruct, Z_Construct_UScriptStruct_FLightningAttachment_Statics::NewStructOps, TEXT("LightningAttachment"), &Z_Registration_Info_UScriptStruct_LightningAttachment, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FLightningAttachment), 4099775772U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_1303388777(TEXT("/Script/Lightnings"),
	nullptr, 0,
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_Statics::ScriptStructInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_Statics::ScriptStructInfo),
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_Statics::EnumInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_Statics::EnumInfo));
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
