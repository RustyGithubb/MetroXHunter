// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

// IWYU pragma: private, include "Framework/LightningEffect.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS
class ALightningEffect;
struct FHitResult;
struct FLightningPattern;
#ifdef LIGHTNINGS_LightningEffect_generated_h
#error "LightningEffect.generated.h already included, missing '#pragma once' in LightningEffect.h"
#endif
#define LIGHTNINGS_LightningEffect_generated_h

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_18_DELEGATE \
LIGHTNINGS_API void FLightningSpawnedSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningSpawnedSignature, ALightningEffect* Lightning);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_19_DELEGATE \
LIGHTNINGS_API void FLightningSparkMoveSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningSparkMoveSignature, ALightningEffect* Lightning, FVector Start, FVector End);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_20_DELEGATE \
LIGHTNINGS_API void FLightningSparkEndMoveSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningSparkEndMoveSignature, ALightningEffect* Lightning);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_21_DELEGATE \
LIGHTNINGS_API void FLightningBranchedSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningBranchedSignature, ALightningEffect* Lightning, ALightningEffect* Branch, int32 BranchOrder);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_22_DELEGATE \
LIGHTNINGS_API void FIntensityChangedSignature_DelegateWrapper(const FMulticastScriptDelegate& IntensityChangedSignature, ALightningEffect* Lightning, float Intensity);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_23_DELEGATE \
LIGHTNINGS_API void FLightningOverlapSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningOverlapSignature, ALightningEffect* Lightning, TArray<FHitResult> const& Overlaps);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_24_DELEGATE \
LIGHTNINGS_API void FLightningHitSignature_DelegateWrapper(const FMulticastScriptDelegate& LightningHitSignature, ALightningEffect* Lightning, FHitResult Hit);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_29_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FLightningIntensityParams_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FLightningIntensityParams>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_RPC_WRAPPERS_NO_PURE_DECLS \
	DECLARE_FUNCTION(execOnLightningHit); \
	DECLARE_FUNCTION(execOnLightningOverlap); \
	DECLARE_FUNCTION(execOnIntensityChanged); \
	DECLARE_FUNCTION(execOnLightningBranched); \
	DECLARE_FUNCTION(execOnLightningSparkEndMove); \
	DECLARE_FUNCTION(execOnLightningSparkMove); \
	DECLARE_FUNCTION(execOnLightningSpawned); \
	DECLARE_FUNCTION(execDoCollisionCheck); \
	DECLARE_FUNCTION(execDeactivate); \
	DECLARE_FUNCTION(execOnBoltFlashing); \
	DECLARE_FUNCTION(execFadeOut); \
	DECLARE_FUNCTION(execDischarge); \
	DECLARE_FUNCTION(execGetOrder); \
	DECLARE_FUNCTION(execIsRoot); \
	DECLARE_FUNCTION(execGetPattern);


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_CALLBACK_WRAPPERS
#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_INCLASS_NO_PURE_DECLS \
private: \
	static void StaticRegisterNativesALightningEffect(); \
	friend struct Z_Construct_UClass_ALightningEffect_Statics; \
public: \
	DECLARE_CLASS(ALightningEffect, AActor, COMPILED_IN_FLAGS(0 | CLASS_Config), CASTCLASS_None, TEXT("/Script/Lightnings"), NO_API) \
	DECLARE_SERIALIZER(ALightningEffect)


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_ENHANCED_CONSTRUCTORS \
private: \
	/** Private move- and copy-constructors, should never be used */ \
	ALightningEffect(ALightningEffect&&); \
	ALightningEffect(const ALightningEffect&); \
public: \
	DECLARE_VTABLE_PTR_HELPER_CTOR(NO_API, ALightningEffect); \
	DEFINE_VTABLE_PTR_HELPER_CTOR_CALLER(ALightningEffect); \
	DEFINE_DEFAULT_CONSTRUCTOR_CALL(ALightningEffect) \
	NO_API virtual ~ALightningEffect();


#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_39_PROLOG
#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_GENERATED_BODY \
PRAGMA_DISABLE_DEPRECATION_WARNINGS \
public: \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_RPC_WRAPPERS_NO_PURE_DECLS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_CALLBACK_WRAPPERS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_INCLASS_NO_PURE_DECLS \
	FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h_42_ENHANCED_CONSTRUCTORS \
private: \
PRAGMA_ENABLE_DEPRECATION_WARNINGS


template<> LIGHTNINGS_API UClass* StaticClass<class ALightningEffect>();

#undef CURRENT_FILE_ID
#define CURRENT_FILE_ID FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningEffect_h


PRAGMA_ENABLE_DEPRECATION_WARNINGS
