// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

#include "UObject/GeneratedCppIncludes.h"
#include "Lightnings/Public/Framework/LightningPattern.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
void EmptyLinkFunctionForGeneratedCodeLightningPattern() {}

// Begin Cross Module References
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FTransform();
COREUOBJECT_API UScriptStruct* Z_Construct_UScriptStruct_FVector();
ENGINE_API UClass* Z_Construct_UClass_UBlueprintFunctionLibrary();
LIGHTNINGS_API UClass* Z_Construct_UClass_ULightningPatternLib();
LIGHTNINGS_API UClass* Z_Construct_UClass_ULightningPatternLib_NoRegister();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningPattern();
LIGHTNINGS_API UScriptStruct* Z_Construct_UScriptStruct_FLightningSparkData();
UPackage* Z_Construct_UPackage__Script_Lightnings();
// End Cross Module References

// Begin ScriptStruct FLightningSparkData
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_LightningSparkData;
class UScriptStruct* FLightningSparkData::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_LightningSparkData.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_LightningSparkData.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FLightningSparkData, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("LightningSparkData"));
	}
	return Z_Registration_Info_UScriptStruct_LightningSparkData.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FLightningSparkData>()
{
	return FLightningSparkData::StaticStruct();
}
struct Z_Construct_UScriptStruct_FLightningSparkData_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* This structure describes a lightning spark position and movement\n*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "This structure describes a lightning spark position and movement" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkPos_MetaData[] = {
		{ "Category", "LightningSpark" },
		{ "Comment", "// Spark world-space coordinates\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Spark world-space coordinates" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkDir_MetaData[] = {
		{ "Category", "LightningSpark" },
		{ "Comment", "// Spark world-space direction\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Spark world-space direction" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkVelocity_MetaData[] = {
		{ "Category", "LightningSpark" },
		{ "Comment", "// Spark scalar velocity value\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Spark scalar velocity value" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkTargetPosIdx_MetaData[] = {
		{ "Category", "LightningSpark" },
		{ "Comment", "// Spark target point index in Points array\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Spark target point index in Points array" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_SparkPos;
	static const UECodeGen_Private::FStructPropertyParams NewProp_SparkDir;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_SparkVelocity;
	static const UECodeGen_Private::FIntPropertyParams NewProp_SparkTargetPosIdx;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FLightningSparkData>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkPos = { "SparkPos", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningSparkData, SparkPos), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkPos_MetaData), NewProp_SparkPos_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkDir = { "SparkDir", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningSparkData, SparkDir), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkDir_MetaData), NewProp_SparkDir_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkVelocity = { "SparkVelocity", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningSparkData, SparkVelocity), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkVelocity_MetaData), NewProp_SparkVelocity_MetaData) };
const UECodeGen_Private::FIntPropertyParams Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkTargetPosIdx = { "SparkTargetPosIdx", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningSparkData, SparkTargetPosIdx), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkTargetPosIdx_MetaData), NewProp_SparkTargetPosIdx_MetaData) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FLightningSparkData_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkPos,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkDir,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkVelocity,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewProp_SparkTargetPosIdx,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningSparkData_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FLightningSparkData_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"LightningSparkData",
	Z_Construct_UScriptStruct_FLightningSparkData_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningSparkData_Statics::PropPointers),
	sizeof(FLightningSparkData),
	alignof(FLightningSparkData),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningSparkData_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FLightningSparkData_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FLightningSparkData()
{
	if (!Z_Registration_Info_UScriptStruct_LightningSparkData.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_LightningSparkData.InnerSingleton, Z_Construct_UScriptStruct_FLightningSparkData_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_LightningSparkData.InnerSingleton;
}
// End ScriptStruct FLightningSparkData

// Begin ScriptStruct FLightningPattern
static FStructRegistrationInfo Z_Registration_Info_UScriptStruct_LightningPattern;
class UScriptStruct* FLightningPattern::StaticStruct()
{
	if (!Z_Registration_Info_UScriptStruct_LightningPattern.OuterSingleton)
	{
		Z_Registration_Info_UScriptStruct_LightningPattern.OuterSingleton = GetStaticStruct(Z_Construct_UScriptStruct_FLightningPattern, (UObject*)Z_Construct_UPackage__Script_Lightnings(), TEXT("LightningPattern"));
	}
	return Z_Registration_Info_UScriptStruct_LightningPattern.OuterSingleton;
}
template<> LIGHTNINGS_API UScriptStruct* StaticStruct<FLightningPattern>()
{
	return FLightningPattern::StaticStruct();
}
struct Z_Construct_UScriptStruct_FLightningPattern_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Struct_MetaDataParams[] = {
		{ "BlueprintType", "true" },
		{ "Comment", "/**\n* This structure describes a lightning, including its child branches.\n* Contains essential geometry params and runtime params of the lightning.\n*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "This structure describes a lightning, including its child branches.\nContains essential geometry params and runtime params of the lightning." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Transform_MetaData[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "// A transformation from FX pattern space to world space\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "A transformation from FX pattern space to world space" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Points_MetaData[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "// Lightning curve points locations, in lightning effect local space\n// These points are connected with ribbons on FX render\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Lightning curve points locations, in lightning effect local space\nThese points are connected with ribbons on FX render" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Length_MetaData[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "// Lightning full length\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Lightning full length" },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_SparkData_MetaData[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "// Lightning spark data\n" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Lightning spark data" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Transform;
	static const UECodeGen_Private::FStructPropertyParams NewProp_Points_Inner;
	static const UECodeGen_Private::FArrayPropertyParams NewProp_Points;
	static const UECodeGen_Private::FFloatPropertyParams NewProp_Length;
	static const UECodeGen_Private::FStructPropertyParams NewProp_SparkData;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static void* NewStructOps()
	{
		return (UScriptStruct::ICppStructOps*)new UScriptStruct::TCppStructOps<FLightningPattern>();
	}
	static const UECodeGen_Private::FStructParams StructParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Transform = { "Transform", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningPattern, Transform), Z_Construct_UScriptStruct_FTransform, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Transform_MetaData), NewProp_Transform_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Points_Inner = { "Points", nullptr, (EPropertyFlags)0x0000000000000000, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, 0, Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FArrayPropertyParams Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Points = { "Points", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Array, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningPattern, Points), EArrayPropertyFlags::None, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Points_MetaData), NewProp_Points_MetaData) };
const UECodeGen_Private::FFloatPropertyParams Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Length = { "Length", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Float, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningPattern, Length), METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Length_MetaData), NewProp_Length_MetaData) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_SparkData = { "SparkData", nullptr, (EPropertyFlags)0x0010000000000014, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(FLightningPattern, SparkData), Z_Construct_UScriptStruct_FLightningSparkData, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_SparkData_MetaData), NewProp_SparkData_MetaData) }; // 3452630830
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UScriptStruct_FLightningPattern_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Transform,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Points_Inner,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Points,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_Length,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UScriptStruct_FLightningPattern_Statics::NewProp_SparkData,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningPattern_Statics::PropPointers) < 2048);
const UECodeGen_Private::FStructParams Z_Construct_UScriptStruct_FLightningPattern_Statics::StructParams = {
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
	nullptr,
	&NewStructOps,
	"LightningPattern",
	Z_Construct_UScriptStruct_FLightningPattern_Statics::PropPointers,
	UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningPattern_Statics::PropPointers),
	sizeof(FLightningPattern),
	alignof(FLightningPattern),
	RF_Public|RF_Transient|RF_MarkAsNative,
	EStructFlags(0x00000001),
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UScriptStruct_FLightningPattern_Statics::Struct_MetaDataParams), Z_Construct_UScriptStruct_FLightningPattern_Statics::Struct_MetaDataParams)
};
UScriptStruct* Z_Construct_UScriptStruct_FLightningPattern()
{
	if (!Z_Registration_Info_UScriptStruct_LightningPattern.InnerSingleton)
	{
		UECodeGen_Private::ConstructUScriptStruct(Z_Registration_Info_UScriptStruct_LightningPattern.InnerSingleton, Z_Construct_UScriptStruct_FLightningPattern_Statics::StructParams);
	}
	return Z_Registration_Info_UScriptStruct_LightningPattern.InnerSingleton;
}
// End ScriptStruct FLightningPattern

// Begin Class ULightningPatternLib Function GetEndPoint
struct Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics
{
	struct LightningPatternLib_eventGetEndPoint_Parms
	{
		FLightningPattern Pattern;
		FVector ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "/**\n\x09* @return the end point of the lightning curve, in world space.\n\x09* Returns zeros if the pattern is not valid.\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "@return the end point of the lightning curve, in world space.\nReturns zeros if the pattern is not valid." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Pattern_MetaData[] = {
		{ "NativeConst", "" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Pattern;
	static const UECodeGen_Private::FStructPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::NewProp_Pattern = { "Pattern", nullptr, (EPropertyFlags)0x0010000008000182, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetEndPoint_Parms, Pattern), Z_Construct_UScriptStruct_FLightningPattern, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Pattern_MetaData), NewProp_Pattern_MetaData) }; // 2025616064
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetEndPoint_Parms, ReturnValue), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::NewProp_Pattern,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ULightningPatternLib, nullptr, "GetEndPoint", nullptr, nullptr, Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::PropPointers), sizeof(Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::LightningPatternLib_eventGetEndPoint_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x14C22401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::Function_MetaDataParams), Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::LightningPatternLib_eventGetEndPoint_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ULightningPatternLib_GetEndPoint()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ULightningPatternLib_GetEndPoint_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ULightningPatternLib::execGetEndPoint)
{
	P_GET_STRUCT_REF(FLightningPattern,Z_Param_Out_Pattern);
	P_FINISH;
	P_NATIVE_BEGIN;
	*(FVector*)Z_Param__Result=ULightningPatternLib::GetEndPoint(Z_Param_Out_Pattern);
	P_NATIVE_END;
}
// End Class ULightningPatternLib Function GetEndPoint

// Begin Class ULightningPatternLib Function GetMiddlePoint
struct Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics
{
	struct LightningPatternLib_eventGetMiddlePoint_Parms
	{
		FLightningPattern Pattern;
		FVector ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "/**\n\x09* @return the point nearly in the middle of the lightning curve, in world space.\n\x09* Returns zeros if the pattern is not valid.\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "@return the point nearly in the middle of the lightning curve, in world space.\nReturns zeros if the pattern is not valid." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Pattern_MetaData[] = {
		{ "NativeConst", "" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Pattern;
	static const UECodeGen_Private::FStructPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::NewProp_Pattern = { "Pattern", nullptr, (EPropertyFlags)0x0010000008000182, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetMiddlePoint_Parms, Pattern), Z_Construct_UScriptStruct_FLightningPattern, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Pattern_MetaData), NewProp_Pattern_MetaData) }; // 2025616064
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetMiddlePoint_Parms, ReturnValue), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::NewProp_Pattern,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ULightningPatternLib, nullptr, "GetMiddlePoint", nullptr, nullptr, Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::PropPointers), sizeof(Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::LightningPatternLib_eventGetMiddlePoint_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x14C22401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::Function_MetaDataParams), Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::LightningPatternLib_eventGetMiddlePoint_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ULightningPatternLib::execGetMiddlePoint)
{
	P_GET_STRUCT_REF(FLightningPattern,Z_Param_Out_Pattern);
	P_FINISH;
	P_NATIVE_BEGIN;
	*(FVector*)Z_Param__Result=ULightningPatternLib::GetMiddlePoint(Z_Param_Out_Pattern);
	P_NATIVE_END;
}
// End Class ULightningPatternLib Function GetMiddlePoint

// Begin Class ULightningPatternLib Function GetPoint
struct Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics
{
	struct LightningPatternLib_eventGetPoint_Parms
	{
		FLightningPattern Pattern;
		int32 PointIndex;
		FVector ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "/**\n\x09* @param PointIndex - an index of the point, which location we want to get.\n\x09* @return the point of the lightning curve at index, in world space.\n\x09* Returns zeros if the pattern is not valid or index is out of range.\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "@param PointIndex - an index of the point, which location we want to get.\n@return the point of the lightning curve at index, in world space.\nReturns zeros if the pattern is not valid or index is out of range." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Pattern_MetaData[] = {
		{ "NativeConst", "" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Pattern;
	static const UECodeGen_Private::FIntPropertyParams NewProp_PointIndex;
	static const UECodeGen_Private::FStructPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::NewProp_Pattern = { "Pattern", nullptr, (EPropertyFlags)0x0010000008000182, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetPoint_Parms, Pattern), Z_Construct_UScriptStruct_FLightningPattern, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Pattern_MetaData), NewProp_Pattern_MetaData) }; // 2025616064
const UECodeGen_Private::FIntPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::NewProp_PointIndex = { "PointIndex", nullptr, (EPropertyFlags)0x0010000000000080, UECodeGen_Private::EPropertyGenFlags::Int, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetPoint_Parms, PointIndex), METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetPoint_Parms, ReturnValue), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::NewProp_Pattern,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::NewProp_PointIndex,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ULightningPatternLib, nullptr, "GetPoint", nullptr, nullptr, Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::PropPointers), sizeof(Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::LightningPatternLib_eventGetPoint_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x14C22401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::Function_MetaDataParams), Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::LightningPatternLib_eventGetPoint_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ULightningPatternLib_GetPoint()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ULightningPatternLib_GetPoint_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ULightningPatternLib::execGetPoint)
{
	P_GET_STRUCT_REF(FLightningPattern,Z_Param_Out_Pattern);
	P_GET_PROPERTY(FIntProperty,Z_Param_PointIndex);
	P_FINISH;
	P_NATIVE_BEGIN;
	*(FVector*)Z_Param__Result=ULightningPatternLib::GetPoint(Z_Param_Out_Pattern,Z_Param_PointIndex);
	P_NATIVE_END;
}
// End Class ULightningPatternLib Function GetPoint

// Begin Class ULightningPatternLib Function GetStartPoint
struct Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics
{
	struct LightningPatternLib_eventGetStartPoint_Parms
	{
		FLightningPattern Pattern;
		FVector ReturnValue;
	};
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Function_MetaDataParams[] = {
		{ "Category", "LightningPattern" },
		{ "Comment", "/**\n\x09* @return the first point of the lightning curve, in world space.\n\x09* Returns zeros if the pattern is not valid.\n\x09*/" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "@return the first point of the lightning curve, in world space.\nReturns zeros if the pattern is not valid." },
	};
	static constexpr UECodeGen_Private::FMetaDataPairParam NewProp_Pattern_MetaData[] = {
		{ "NativeConst", "" },
	};
#endif // WITH_METADATA
	static const UECodeGen_Private::FStructPropertyParams NewProp_Pattern;
	static const UECodeGen_Private::FStructPropertyParams NewProp_ReturnValue;
	static const UECodeGen_Private::FPropertyParamsBase* const PropPointers[];
	static const UECodeGen_Private::FFunctionParams FuncParams;
};
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::NewProp_Pattern = { "Pattern", nullptr, (EPropertyFlags)0x0010000008000182, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetStartPoint_Parms, Pattern), Z_Construct_UScriptStruct_FLightningPattern, METADATA_PARAMS(UE_ARRAY_COUNT(NewProp_Pattern_MetaData), NewProp_Pattern_MetaData) }; // 2025616064
const UECodeGen_Private::FStructPropertyParams Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::NewProp_ReturnValue = { "ReturnValue", nullptr, (EPropertyFlags)0x0010000000000580, UECodeGen_Private::EPropertyGenFlags::Struct, RF_Public|RF_Transient|RF_MarkAsNative, nullptr, nullptr, 1, STRUCT_OFFSET(LightningPatternLib_eventGetStartPoint_Parms, ReturnValue), Z_Construct_UScriptStruct_FVector, METADATA_PARAMS(0, nullptr) };
const UECodeGen_Private::FPropertyParamsBase* const Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::PropPointers[] = {
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::NewProp_Pattern,
	(const UECodeGen_Private::FPropertyParamsBase*)&Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::NewProp_ReturnValue,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::PropPointers) < 2048);
const UECodeGen_Private::FFunctionParams Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::FuncParams = { (UObject*(*)())Z_Construct_UClass_ULightningPatternLib, nullptr, "GetStartPoint", nullptr, nullptr, Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::PropPointers, UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::PropPointers), sizeof(Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::LightningPatternLib_eventGetStartPoint_Parms), RF_Public|RF_Transient|RF_MarkAsNative, (EFunctionFlags)0x14C22401, 0, 0, METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::Function_MetaDataParams), Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::Function_MetaDataParams) };
static_assert(sizeof(Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::LightningPatternLib_eventGetStartPoint_Parms) < MAX_uint16);
UFunction* Z_Construct_UFunction_ULightningPatternLib_GetStartPoint()
{
	static UFunction* ReturnFunction = nullptr;
	if (!ReturnFunction)
	{
		UECodeGen_Private::ConstructUFunction(&ReturnFunction, Z_Construct_UFunction_ULightningPatternLib_GetStartPoint_Statics::FuncParams);
	}
	return ReturnFunction;
}
DEFINE_FUNCTION(ULightningPatternLib::execGetStartPoint)
{
	P_GET_STRUCT_REF(FLightningPattern,Z_Param_Out_Pattern);
	P_FINISH;
	P_NATIVE_BEGIN;
	*(FVector*)Z_Param__Result=ULightningPatternLib::GetStartPoint(Z_Param_Out_Pattern);
	P_NATIVE_END;
}
// End Class ULightningPatternLib Function GetStartPoint

// Begin Class ULightningPatternLib
void ULightningPatternLib::StaticRegisterNativesULightningPatternLib()
{
	UClass* Class = ULightningPatternLib::StaticClass();
	static const FNameNativePtrPair Funcs[] = {
		{ "GetEndPoint", &ULightningPatternLib::execGetEndPoint },
		{ "GetMiddlePoint", &ULightningPatternLib::execGetMiddlePoint },
		{ "GetPoint", &ULightningPatternLib::execGetPoint },
		{ "GetStartPoint", &ULightningPatternLib::execGetStartPoint },
	};
	FNativeFunctionRegistrar::RegisterFunctions(Class, Funcs, UE_ARRAY_COUNT(Funcs));
}
IMPLEMENT_CLASS_NO_AUTO_REGISTRATION(ULightningPatternLib);
UClass* Z_Construct_UClass_ULightningPatternLib_NoRegister()
{
	return ULightningPatternLib::StaticClass();
}
struct Z_Construct_UClass_ULightningPatternLib_Statics
{
#if WITH_METADATA
	static constexpr UECodeGen_Private::FMetaDataPairParam Class_MetaDataParams[] = {
		{ "Comment", "/**\n* Helper BP functions for lightning patterns.\n* It is needed because the USTRUCTs don't support UFUNCTIONs.\n*/" },
		{ "IncludePath", "Framework/LightningPattern.h" },
		{ "ModuleRelativePath", "Public/Framework/LightningPattern.h" },
		{ "ToolTip", "Helper BP functions for lightning patterns.\nIt is needed because the USTRUCTs don't support UFUNCTIONs." },
	};
#endif // WITH_METADATA
	static UObject* (*const DependentSingletons[])();
	static constexpr FClassFunctionLinkInfo FuncInfo[] = {
		{ &Z_Construct_UFunction_ULightningPatternLib_GetEndPoint, "GetEndPoint" }, // 2210967575
		{ &Z_Construct_UFunction_ULightningPatternLib_GetMiddlePoint, "GetMiddlePoint" }, // 2796844738
		{ &Z_Construct_UFunction_ULightningPatternLib_GetPoint, "GetPoint" }, // 1314506223
		{ &Z_Construct_UFunction_ULightningPatternLib_GetStartPoint, "GetStartPoint" }, // 1163543160
	};
	static_assert(UE_ARRAY_COUNT(FuncInfo) < 2048);
	static constexpr FCppClassTypeInfoStatic StaticCppClassTypeInfo = {
		TCppClassTypeTraits<ULightningPatternLib>::IsAbstract,
	};
	static const UECodeGen_Private::FClassParams ClassParams;
};
UObject* (*const Z_Construct_UClass_ULightningPatternLib_Statics::DependentSingletons[])() = {
	(UObject* (*)())Z_Construct_UClass_UBlueprintFunctionLibrary,
	(UObject* (*)())Z_Construct_UPackage__Script_Lightnings,
};
static_assert(UE_ARRAY_COUNT(Z_Construct_UClass_ULightningPatternLib_Statics::DependentSingletons) < 16);
const UECodeGen_Private::FClassParams Z_Construct_UClass_ULightningPatternLib_Statics::ClassParams = {
	&ULightningPatternLib::StaticClass,
	nullptr,
	&StaticCppClassTypeInfo,
	DependentSingletons,
	FuncInfo,
	nullptr,
	nullptr,
	UE_ARRAY_COUNT(DependentSingletons),
	UE_ARRAY_COUNT(FuncInfo),
	0,
	0,
	0x001000A0u,
	METADATA_PARAMS(UE_ARRAY_COUNT(Z_Construct_UClass_ULightningPatternLib_Statics::Class_MetaDataParams), Z_Construct_UClass_ULightningPatternLib_Statics::Class_MetaDataParams)
};
UClass* Z_Construct_UClass_ULightningPatternLib()
{
	if (!Z_Registration_Info_UClass_ULightningPatternLib.OuterSingleton)
	{
		UECodeGen_Private::ConstructUClass(Z_Registration_Info_UClass_ULightningPatternLib.OuterSingleton, Z_Construct_UClass_ULightningPatternLib_Statics::ClassParams);
	}
	return Z_Registration_Info_UClass_ULightningPatternLib.OuterSingleton;
}
template<> LIGHTNINGS_API UClass* StaticClass<ULightningPatternLib>()
{
	return ULightningPatternLib::StaticClass();
}
ULightningPatternLib::ULightningPatternLib(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer) {}
DEFINE_VTABLE_PTR_HELPER_CTOR(ULightningPatternLib);
ULightningPatternLib::~ULightningPatternLib() {}
// End Class ULightningPatternLib

// Begin Registration
struct Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_Statics
{
	static constexpr FStructRegisterCompiledInInfo ScriptStructInfo[] = {
		{ FLightningSparkData::StaticStruct, Z_Construct_UScriptStruct_FLightningSparkData_Statics::NewStructOps, TEXT("LightningSparkData"), &Z_Registration_Info_UScriptStruct_LightningSparkData, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FLightningSparkData), 3452630830U) },
		{ FLightningPattern::StaticStruct, Z_Construct_UScriptStruct_FLightningPattern_Statics::NewStructOps, TEXT("LightningPattern"), &Z_Registration_Info_UScriptStruct_LightningPattern, CONSTRUCT_RELOAD_VERSION_INFO(FStructReloadVersionInfo, sizeof(FLightningPattern), 2025616064U) },
	};
	static constexpr FClassRegisterCompiledInInfo ClassInfo[] = {
		{ Z_Construct_UClass_ULightningPatternLib, ULightningPatternLib::StaticClass, TEXT("ULightningPatternLib"), &Z_Registration_Info_UClass_ULightningPatternLib, CONSTRUCT_RELOAD_VERSION_INFO(FClassReloadVersionInfo, sizeof(ULightningPatternLib), 2981931939U) },
	};
};
static FRegisterCompiledInInfo Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_4729575(TEXT("/Script/Lightnings"),
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_Statics::ClassInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_Statics::ClassInfo),
	Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_Statics::ScriptStructInfo, UE_ARRAY_COUNT(Z_CompiledInDeferFile_FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningPattern_h_Statics::ScriptStructInfo),
	nullptr, 0);
// End Registration
PRAGMA_ENABLE_DEPRECATION_WARNINGS
