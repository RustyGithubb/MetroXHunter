// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

// IWYU pragma: private, include "Parameters/LightningType.h"
#include "Templates/IsUEnumClass.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ReflectedTypeAccessors.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS
#ifdef LIGHTNINGS_LightningType_generated_h
#error "LightningType.generated.h already included, missing '#pragma once' in LightningType.h"
#endif
#define LIGHTNINGS_LightningType_generated_h

#undef CURRENT_FILE_ID
#define CURRENT_FILE_ID FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Parameters_LightningType_h


#define FOREACH_ENUM_ELIGHTNINGTYPE(op) \
	op(ELightningType::LT_Root) \
	op(ELightningType::LT_Branch) 

enum class ELightningType : uint8;
template<> struct TIsUEnumClass<ELightningType> { enum { Value = true }; };
template<> LIGHTNINGS_API UEnum* StaticEnum<ELightningType>();

PRAGMA_ENABLE_DEPRECATION_WARNINGS
