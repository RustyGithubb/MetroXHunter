// Copyright Epic Games, Inc. All Rights Reserved.
/*===========================================================================
	Generated code exported from UnrealHeaderTool.
	DO NOT modify this manually! Edit the corresponding .h files instead!
===========================================================================*/

// IWYU pragma: private, include "Framework/LightningAttachment.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS
#ifdef LIGHTNINGS_LightningAttachment_generated_h
#error "LightningAttachment.generated.h already included, missing '#pragma once' in LightningAttachment.h"
#endif
#define LIGHTNINGS_LightningAttachment_generated_h

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_63_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FAttachVolumeBox_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FAttachVolumeBox>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_72_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FAttachVolumeCylinder_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FAttachVolumeCylinder>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_85_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FAttachVolumeSphere_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FAttachVolumeSphere>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_98_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FActorAttachParams_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FActorAttachParams>();

#define FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h_126_GENERATED_BODY \
	friend struct Z_Construct_UScriptStruct_FLightningAttachment_Statics; \
	LIGHTNINGS_API static class UScriptStruct* StaticStruct();


template<> LIGHTNINGS_API UScriptStruct* StaticStruct<struct FLightningAttachment>();

#undef CURRENT_FILE_ID
#define CURRENT_FILE_ID FID_Projects_Plugins_Lightnings_Package_v5_4_HostProject_Plugins_Lightnings_Source_Lightnings_Public_Framework_LightningAttachment_h


#define FOREACH_ENUM_EATTACHTYPE(op) \
	op(EAttachType::AT_Self) \
	op(EAttachType::AT_Location) \
	op(EAttachType::AT_Actor) 

enum class EAttachType : uint8;
template<> struct TIsUEnumClass<EAttachType> { enum { Value = true }; };
template<> LIGHTNINGS_API UEnum* StaticEnum<EAttachType>();

#define FOREACH_ENUM_EATTACHVOLUMETYPE(op) \
	op(EAttachVolumeType::AV_Point) \
	op(EAttachVolumeType::AV_Box) \
	op(EAttachVolumeType::AV_Cylinder) \
	op(EAttachVolumeType::AV_Sphere) 

enum class EAttachVolumeType : uint8;
template<> struct TIsUEnumClass<EAttachVolumeType> { enum { Value = true }; };
template<> LIGHTNINGS_API UEnum* StaticEnum<EAttachVolumeType>();

#define FOREACH_ENUM_EATTACHACTORDIRECTIONSPACE(op) \
	op(EAttachActorDirectionSpace::DS_World) \
	op(EAttachActorDirectionSpace::DS_Actor) \
	op(EAttachActorDirectionSpace::DS_Component) \
	op(EAttachActorDirectionSpace::DS_Socket) 

enum class EAttachActorDirectionSpace : uint8;
template<> struct TIsUEnumClass<EAttachActorDirectionSpace> { enum { Value = true }; };
template<> LIGHTNINGS_API UEnum* StaticEnum<EAttachActorDirectionSpace>();

PRAGMA_ENABLE_DEPRECATION_WARNINGS
